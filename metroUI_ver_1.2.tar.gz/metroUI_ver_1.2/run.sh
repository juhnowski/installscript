cd /home/user/transos/app
./run.sh
./run.sh
cd /root/user-dm/Lua_project/workDirect/metroUI_ver_1.2
tarantool metroUI.lua
