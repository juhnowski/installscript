local exports = {}

exports.password = ""

-- получить URL камер
-- ip строго определены для вагонов

exports.getA1 = function()
    return "rtsp://10.0.0.11:..."
end

exports.getB1 = function()
    return "rtsp://10.0.0.11:..."
end

exports.getA2 = function()
    return "rtsp://10.0.0.12:..."
end

exports.getB2 = function()
    return "rtsp://10.0.0.12:..."
end

exports.getA3 = function()
    return "rtsp://10.0.0.13:..."
end

exports.getB3 = function()
    return "rtsp://10.0.0.13:..."
end

exports.getA4 = function()
    return "rtsp://10.0.0.14:..."
end

exports.getB4 = function()
    return "rtsp://10.0.0.14:..."
end

exports.getK1 = function()
    return "rtsp://10.0.0.11:..."
end

exports.getK4 = function()
    return "rtsp://10.0.0.14:..."
end

exports.getD1 = function()
    return "rtsp://10.0.0.11:..."
end

exports.getD4 = function()
    return "rtsp://10.0.0.14:..."
end

-- получить массив строковых индексов видеокамер в зависимости от АРМ для раскладки 3х3
-- нулевая камера в кабине противоположной той в которой находится АРМ
exports.get3x3 = function(arm_number)
	if arm_number == 1 then
	    return {"K4",
				"A1","B1","A4",
				"A2","B2","B4",
				"A3","B3","D4"
			   }
	elseif
		return {"K1",
				"A1","B1","A4",
				"A2","B2","B4",
				"A3","B3","D1"
			   }
	end
end

-- получить массив строковых индексов видеокамер в зависимости от АРМ для раскладки 2х3
-- нулевой и ндекс - пустая строка, для соответствия с документом презентации
exports.get2x3 = function(arm_number)
	if arm_number == 1 then
	    return {"",
				"D1","A1",
					 "B2",
				"A2","B2","K1"
				}
	elseif
		return {"",
				"D4","A3",
					 "B3",
				"A4","B4","K4"
				}
	end
end

-- получить массив строковых индексов видеокамер для раскладки 2х2 в зависимости от порядкового числа - индекса
exports.get2x2 = function(idx)
	switch(idx) {
		[1] = function () 
					return {
								"A1","B1",
								"A2"."B2"
						   } end,	
		[2] = function () 
					return {
								"A3","B3",
								"A4","B4"
						   } end,
		[3] = function ()
					return {
								"K1","D1",
								"K4","D4"
						   } end,
		[Default] = function () 
					return {
								"A1","B1",
								"A2"."B2"
						   } end
	}
end

-- Функция проверки пароля для входа в настройки
exports.auth = function(password)
	if password == 999 then
		return true
	else
		return false
	end
end

-- Функции настроек
-- Яркость по умолчанию
exports.brightness = 50
-- Шаг прибавления яркости
exports.brightness_step = 10

-- Увеличить яркость на одно деление
exports.up_brightness = function ()
	if exports.brightness <100 then
		exports.brightness = exports.brightness + exports.brightness_step
	end
		
	return exports.brightness
end

-- Уменьшить яркость на одно деление
exports.down_brightness = function ()
	if exports.brightness <100 then
		exports.brightness = exports.brightness - exports.brightness_step
	end
		
	return exports.brightness
end

-- Контрастность по умолчанию
exports.contrast = 50
exports.contrast_step = 10

exports.up_contrast = function ()
	if exports.contrast <100 then
		exports.contrast = exports.contrast + exports.contrast_step
	end
		
	return exports.contrast
end

-- Уменьшить контрастность на одно деление
exports.down_contrast = function ()
	if exports.contrast <100 then
		exports.contrast = exports.contrast - exports.contrast_step
	end
		
	return exports.contrast
end


-- Сдвиг экрана по вертикали и горизонтали
exports.shift_x = 0
exports.shift_y = 0
exports.shift_step = 1

-- Сдвинуть вправо
exports.up_shift_x = function ()
	if exports.shift_x <  600 then
		exports.shift_x = exports.shift_x + exports.shift_step
	end
		
	return exports.shift_x
end

-- Сдвинуть влево
exports.down_shift_x = function ()
	if exports.shift_x > -600 then
		exports.shift_x = exports.shift_x - exports.shift_step
	end
		
	return exports.shift_x
end

-- Сдвинуть вверх
exports.up_shift_y = function ()
	if exports.shift_y < 800 then
		exports.shift_y = exports.shift_y + exports.shift_step
	end
		
	return exports.shift_y
end

-- Сдвинуть вниз
exports.down_shift_y = function ()
	if exports.shift_y > -800 then
		exports.shift_y = exports.shift_y - exports.shift_step
	end
		
	return exports.shift_y
end

-- Сжатие экрана по вертикали и горизонтали
exports.compress_x = 0
exports.compress_y = 0
exports.compress_step = 0.1

-- Растянуть по x
exports.up_compress_x = function ()
	if exports.compress_x <  5 then
		exports.compress_x = exports.compress_x + exports.compress_step
	end
		
	return exports.compress_x
end

-- Сжать по x
exports.down_compress_x = function ()
	if exports.compress_x >-5 then
		exports.compress_x = exports.compress_x - exports.compress_step
	end
		
	return exports.compress_x
end

-- Растянуть по y
exports.up_compress_y = function ()
	if exports.compress_y < 5 then
		exports.compress_y = exports.compress_y + exports.compress_step
	end
		
	return exports.compress_y
end

-- Сжать по y
exports.down_compress_y = function ()
	if exports.compress_y >-5 then
		exports.compress_y = exports.compress_y - exports.compress_step
	end
		
	return exports.compress_y
end

-- Клавиши
exports.KEY_F1 = 1
exports.KEY_F2 = 2
exports.KEY_F3 = 3
exports.KEY_F4 = 4
exports.KEY_F5 = 5
exports.KEY_F6 = 6
exports.KEY_F12 = 12

exports.KEY_Num0 = 100
exports.KEY_Num1 = 101
exports.KEY_Num2 = 102
exports.KEY_Num3 = 103
exports.KEY_Num4 = 104
exports.KEY_Num5 = 105
exports.KEY_Num6 = 106
exports.KEY_Num7 = 107
exports.KEY_Num8 = 108
exports.KEY_Num9 = 109
exports.KEY_ENTER = 110

exports.KEY_ESC = 999

-- Состояния
exports.STATE_3X3 = 1
exports.STATE_SCHEMA = 2
exports.STATE_VIDEO_SETTINGS = 3
exports.STATE_SYSTEM_SETTINGS = 4
exports.STATE_LOGIN = 5
exports.STATE_2X2_1 = 61
exports.STATE_2X2_2 = 62
exports.STATE_2X2_3 = 63
exports.STATE_2X3_1 = 71
exports.STATE_2X3_2 = 72

-- Текущее состояние
exports.state = exports.STATE_3x3

-- Обработчик
exports.on_change_state = function (key_value)
    switch(key_value) {
		[exports.KEY_F1] = function () 
								if exports.state == exports.STATE_3X3 then
									exports.state = exports.STATE_SCHEMA
									exports.showSchema()
									return exports.STATE_SCHEMA
								else
									exports.state = exports.STATE_3X3
									exports.show3x3()
									return exports.STATE_3X3
								end
							end,	
		[exports.KEY_F2] = function () 
								if exports.state == exports.STATE_VIDEO_SETTINGS then
									return exports.STATE_VIDEO_SETTINGS								
								else
									exports.state = exports.STATE_VIDEO_SETTINGS
									exports.showVideoSettings()
									return exports.STATE_VIDEO_SETTINGS
								end
						 	end,
		[exports.KEY_F3] = function ()
								if exports.state == exports.STATE_SYSTEM_SETTINGS then
									return exports.STATE_SYSTEM_SETTINGS
								else
									exports.state = exports.STATE_LOGIN
									exports.showLogin()
									return exports.STATE_LOGIN
								end
						 	end,
		[exports.KEY_ENTER] = 	function ()
									if exports.state == exports.STATE_LOGIN then
										if exports.auth(exports.password) then
											exports.state = exports.STATE_SYSTEM_SETTINGS
											exports.showSystemSetings()
											return exports.STATE_SYSTEM_SETTINGS
										else
											exports.showLogin()
											return exports.STATE_LOGIN
										end
									end
								end,	
		[Default] = 		function () 
								if exports.state == exports.STATE_3X3 then
									return exports.STATE_3X3
								else
									exports.state = exports.STATE_3X3
									exports.show3x3()
									return exports.STATE_3X3
								end
							 end
	}
end

-- Функции отображения на экране
exports.show3x3() = function ()

end

exports.showSchema() = function ()

end

exports.showVideoSettings() = function ()

end

exports.showSystemSetings() = function ()

end

exports.showLogin() = function ()
	exports.password = ""
end

exports.show2x2() = function ()

end

exports.show2x3() = function ()

end

-- Обработчики нажатия клавиш
exports.onClickF1 = function ()

end

exports.onClickF2 = function ()

end

exports.onClickF3 = function ()

end

exports.onClickF4 = function ()

end

exports.onClickF5 = function ()

end

exports.onClickF6 = function ()

end

exports.onClickF12 = function ()

end

-- Input functions and variable

exports.add_char_to_password = function(ch)
	exports.password = exports.password .. ch
end

return exports

