#!/usr/bin/tarantool
box.cfg{
 snapshot_period = 3600,
 snapshot_count = 3
};

ui = require "tek.ui"
exec = require "tek.lib.exec"
MenuItem = ui.MenuItem;

scheme = require "pages.scheme";
BK_Sets = require "pages.BK_Sets";
videoreg = require "pages.BK_Sets.videoreg"
ip_camera = require "pages.BK_Sets.ip_camera";

--Загрузка раскладок.
video_2x2 = require "pages.layout_screen.video_2x2";
video_2x3 = require "pages.layout_screen.video_2x3";
video_3x3 = require "pages.layout_screen.video_3x3";

--Загрузка настроек параметров экрана.
screen_sets = require "pages.screen_sets.screen_sets";

i = 0;

ui.Mode = "workbench";

function playfb()
	os.execute("./main_1");
        os.execute("./main_2");
        os.execute("./playfb -u -sx -a - -x 5 -y 28 -z 0.73 -w 0.5 udp://127.0.0.1:9000 &");
        os.execute("./playfb -u -sx -a - -x 272 -y 28 -z 0.73 -w 0.5 udp://127.0.0.1:9002 &");
	i = 1;
end

function playfb_2x2()
	os.execute("pkill playfb");
	os.execute("./main_1");
	os.execute("./main_2");
	os.execute("./playfb -u -sx -a - -x 5 -y 28 -z 1.11 -w 0.76 udp://127.0.0.1:9000 &");
        os.execute("./playfb -u -sx -a - -x 405 -y 28 -z 1.11 -w 0.76 udp://127.0.0.1:9002 &");
	i = 1;
end

function playfb_2x3()
	os.execute("pkill playfb");
        os.execute("./main_1");
        os.execute("./main_2");
        os.execute("./playfb -u -sx -a - -x 5 -y 28 -z 1.47 -w 1.03 udp://127.0.0.1:9000 &");
	os.execute("./playfb -u -sx -a - -x 534 -y 28 -z 0.73 -w 0.5 udp://127.0.0.1:9002 &");
        i = 1;
end

app = ui.Application:new
{
	Id = "the-application",
	Children =
	{
		ui.Window:new
		{
			Title = "Canvas and Scrollgroup",
			HideOnEscape = true,
			Orientation = "vertical",
			FullScreen = true,
			Width = 800;
			Height = 480;
			--MaxWidth = 1366;
			--MaxHeight = 768;
			Id = "the-window",
			RootWindow = true;
			SizeButton = true;
			Children =
			{
				ui.Group:new
				{
					Orientation = "horizontal";
					Status = "hide";
					Children =
					{
						MenuItem:new
						{
							Text = "F1-Настройки";
							Shortcut = "F1";
							onClick = function(self)
								self:getById("id-set"):setValue("Status","show");
								if i == 1 then
									i = 0;
									os.execute("pkill playfb");
								end
							end
						},
						MenuItem:new
                		                {
							Text = "F2-Карта";
                                		        Shortcut = "F2";
                                        		onClick = function(self)
	                                                	self:getById("id-map"):setValue("Status","show");
								if i == 1 then
                                                                        i = 0;
                                                                        os.execute("pkill playfb");
                                                                end
	        	                                end
        	        	                },
						MenuItem:new
                                                {
                                                        Text = "F3-Экран";
                                                        Shortcut = "F3";
                                                        onClick = function(self)
                                                                self:getById("id_scr_set"):setValue("Status","show");
                                                                if i == 1 then
                                                                        i = 0;
                                                                        os.execute("pkill playfb");
                                                                end
                                                        end
                                                },
						MenuItem:new
                                                {
                                                        Text = "F4-Раскладка 2x2";
                                                        Shortcut = "F4";
                                                        onClick = function(self)
                                                                self:getById("id_2x2"):setValue("Status","show");
                                                                if i == 1 then
                                                                        i = 0;
                                                                        os.execute("pkill playfb");
									playfb_2x2();
								elseif i == 0 then
									playfb_2x2();
                                                                end
                                                        end
                                                },
						MenuItem:new
                                                {
                                                        Text = "F5-Раскладка 2x3";
                                                        Shortcut = "F5";
                                                        onClick = function(self)
                                                                self:getById("id_2x3"):setValue("Status","show");
                                                                if i == 1 then
                                                                        i = 0;
                                                                        os.execute("pkill playfb");
									playfb_2x3();
								elseif i == 0 then
									playfb_2x3();
                                                                end
                                                        end
                                                },
					}
				},
				ui.Group:new
				{	
					Orientation = horizontal;
					Weight = 0x5000;
					Children =
					{
						ui.Text:new
						{
							Style = "background-color:black";
							Height = "free";
							Text = "1";
						},
						ui.Text:new
                                                {	
							Style = "background-color:black";
							Height = "free";
                                                        Text = "2";
                                                },
						ui.Text:new
                                                {
							Style = "background-color:black";
							Height = "free";
                                                        Text = "3";
                                                },
					}	
				},
				ui.Group:new
                                {
                                        Orientation = horizontal;
					Weight = 0x5000;
                                        Children =
                                        {
                                                ui.Text:new
                                                {
							Style = "background-color:black";
							Height = "free";
                                                        Text = "4";
                                                },
                                                ui.Text:new
                                                {
							Style = "background-color:black";
							Height = "free";
                                                        Text = "5";
                                                },
                                                ui.Text:new
                                                {
							Style = "background-color:black";
							Height = "free";
                                                        Text = "6";
                                                },
                                        }
                                },
				ui.Group:new
                                {
                                        Orientation = horizontal;
					Weight = 0x5000;
                                        Children =
                                        {
                                                ui.Text:new
                                                {
							Style = "background-color:black";
							Height = "free";
                                                        Text = "7";
                                                },
                                                ui.Text:new
                                                {
							Style = "background-color:black";
							Height = "free";
                                                        Text = "8";
                                                },
                                                ui.Text:new
                                                {
							Style = "background-color:black";
							Height = "free";
                                                        Text = "9";
                                                },
                                        }
                                },
			},
		}
	}

}

ui.Application.connect(BK_Sets);
ui.Application.connect(scheme);
ui.Application.connect(videoreg);
ui.Application.connect(ip_camera);
ui.Application.connect(video_2x2);
ui.Application.connect(video_2x3);
ui.Application.connect(screen_sets);
--ui.Application.connect(video_3x3);

app:addMember(scheme);
app:addMember(BK_Sets);
app:addMember(videoreg);
app:addMember(ip_camera);
app:addMember(video_2x2);
app:addMember(video_2x3);
app:addMember(screen_sets);
--app:addMember(video_3x3);

playfb();

app:run()
app:hide()
app:cleanup()
