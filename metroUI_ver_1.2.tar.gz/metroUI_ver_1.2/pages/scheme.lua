local ui = require("tek.ui")

local PPM_SendMsg = ui.loadImage("1.ppm")

local window_scheme = ui.Window:new
{
        Title = "BK sets",
        HideOnEscape = true,
        Orientation = "vertical",
        FullScreen = true;
        Width = 800;
        Height = 480;
        Id = "id-map",
        Status = "hide";
        Children =
        {
		ui.Text:new
		{
			Height = "free";
			Width = "free";
			Style = "background-image: url(2.ppm)";
		}
	}
}

return window_scheme;
