local video_2x2 = {}

local ui = require("tek.ui")

local video_2x2 = ui.Window:new
{
        Title = "layout_2x2",
        HideOnEscape = true,
        Orientation = "vertical",
        FullScreen = true;
        Width = 800;
        Height = 480;
        Id = "id_2x2",
        Status = "hide";
        Children =
        {
		ui.Group:new
               	{
                	Orientation = "horizontal";
                       	Status = "hide";
                       	Children =
                      	{
                        	MenuItem:new
                                {
                                	Text = "F1-Настройки";
                                        Shortcut = "F1";
                                        onClick = function(self)
						self:getById("id_2x2"):setValue("Status","hide");
                                        	self:getById("id-set"):setValue("Status","show");
                                               	if i == 1 then
                                                	i = 0;
                                                        os.execute("pkill playfb");
                                                end
                                       	end
                              	},
				MenuItem:new
                                {
                                	Text = "F2-Карта";
                                        Shortcut = "F2";
                                        onClick = function(self)
						self:getById("id_2x2"):setValue("Status","hide");
                                       		self:getById("id-map"):setValue("Status","show");
                                                if i == 1 then
                                               		i = 0;
                                                        os.execute("pkill playfb");
                                              	end
                                       	end
                             	},
                                MenuItem:new
                                {
                               		Text = "F5-Раскладка 2x3";
                                        Shortcut = "F5";
                                        onClick = function(self)
						self:getById("id_2x2"):setValue("Status","hide");
                                        	self:getById("id_2x3"):setValue("Status","show");
                                                if i == 1 then
                                                	i = 0;
							playfb_2x3();
                                                       	--os.execute("pkill playfb");
                                               	end
                                       	end
                               	},
			}
		},
		ui.Group:new
               	{
               		Orientation = horizontal;
                        Weight = 0x5000;
                       	Children =
                       	{
                        	ui.Text:new
                                {
                                	Style = "background-color:black";
                                        Height = "free";
                                        Text = "1";
                                },
                                ui.Text:new
                               	{
                                      	Style = "background-color:black";
                                       	Height = "free";
                                        Text = "2";
                                },
                        }
                },
		ui.Group:new
                {
                        Orientation = horizontal;
                        Weight = 0x5000;
                        Children =
                        {
                                ui.Text:new
                                {
                                        Style = "background-color:black";
                                        Height = "free";
                                        Text = "1";
                                },
                                ui.Text:new
                                {
                                        Style = "background-color:black";
                                        Height = "free";
                                        Text = "2";
                                },
                        }
                }
        }
}

return video_2x2;
