local password = {}

local ui = require("tek.ui")

local password = ui.Window:new
{
        Title = "password",
        HideOnEscape = true,
        Orientation = "vertical",
        FullScreen = true;
        Width = 800;
        Height = 480;
        Id = "id_pass",
        Status = "hide";
        Children =
        {
		
	}
}


return password;
