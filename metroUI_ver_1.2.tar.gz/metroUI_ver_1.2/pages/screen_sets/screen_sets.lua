local screen_sets = {}

local ui = require("tek.ui")

local screen_sets = ui.Window:new
{
        Title = "screen_sets";
        HideOnEscape = true;
        Orientation = "vertical";
        FullScreen = true;
        Width = 800;
        Height = 480;
        Id = "id_scr_set";
        Status = "hide";
        Children =
        {
		ui.Group:new
		{
			Children =
			{
				ui.Text:new
				{
					Text = "Яркость";
					Style = "font: ui-x-large; text: x-large";
					Width = 200;
				},
				ui.Input:new
				{
					Width = 200;
					Style = "font: ui-x-large; text: x-large";
				}
			}
		},
		ui.Group:new
                {
                        Children =
                        {
                                ui.Text:new
                                {
                                        Text = "Контрастность";
					Style = "font: ui-x-large; text: x-large";
					Width = 200;
                                },
                                ui.Input:new
                                {
					Style = "font: ui-x-large; text: x-large";
					Width = 200;
                                }
                        }
                },
		ui.Group:new
                {
                        Children =
                        {
                                ui.Text:new
                                {
                                        Text = "Сдвиг по X";
					Style = "font: ui-x-large; text: x-large";
                                        Width = 200;
                                },
                                ui.Input:new
                                {
                                        Width = 200;
					Style = "font: ui-x-large; text: x-large";
                                }
                        }
                },
		ui.Group:new
                {
                        Children =
                        {
                                ui.Text:new
                                {
					Style = "font: ui-x-large; text: x-large";
                                        Text = "Сдвиг по Y";
                                        Width = 200;
                                },
                                ui.Input:new
                                {
					Style = "font: ui-x-large; text: x-large";
                                        Width = 200;
                                }
                        }
                },
		ui.Group:new
                {
                        Children =
                        {
                                ui.Text:new
                                {
					Style = "font: ui-x-large; text: x-large";
                                        Text = "Сжатие по X";
                                        Width = 200;
                                },
                                ui.Input:new
                                {
					Style = "font: ui-x-large; text: x-large";
                                        Width = 200;
                                }
                        }
                },
		ui.Group:new
                {
                        Children =
                        {
                                ui.Text:new
                                {
					Style = "font: ui-x-large; text: x-large";
                                        Text = "Сжатие по Y";
                                        Width = 200;
                                },
                                ui.Input:new
                                {
					Style = "font: ui-x-large; text: x-large";
                                        Width = 200;
                                }
                        }
                },
	}
}

return screen_sets;
