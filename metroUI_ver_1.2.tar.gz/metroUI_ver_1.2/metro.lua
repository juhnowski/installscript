--[[

http://json.luaforge.net/

Pre-installation:
    luarocks search JSON4Lua
    sudo luarocks install json4lua
--]]
local exports = {}
json = require("json")

exports.password = ""
-- сохраняем начальное значение при редактировании, для того чтобы по ESC вернуть значение
exports.edit_old_value = ""
exports.edit_new_value = ""
exports.isDebug = true

exports.debug = function(msg)
    if exports.isDebug then
        print (msg)
    end
end

-- получить URL камер
-- ip строго определены для вагонов
exports.A1 = "rtsp://10.0.0.11:..."
exports.B1 = "rtsp://10.0.0.11:..."
exports.A2 = "rtsp://10.0.0.12:..."
exports.B2 = "rtsp://10.0.0.12:..."
exports.A3 = "rtsp://10.0.0.13:..."
exports.B3 = "rtsp://10.0.0.13:..."
exports.A4 = "rtsp://10.0.0.14:..."
exports.B4 = "rtsp://10.0.0.14:..."
exports.K1 = "rtsp://10.0.0.11:..."
exports.K4 = "rtsp://10.0.0.14:..."
exports.D1 = "rtsp://10.0.0.11:..."
exports.D4 = "rtsp://10.0.0.14:..."

-- фугкции get 
-- TODO: добавить в функции проверку соединения
exports.getA1 = function()
    return exports.A1 
end

exports.getB1 = function()
    return exports.B1
end

exports.getA2 = function()
    return exports.A2
end

exports.getB2 = function()
    return exports.B2
end

exports.getA3 = function()
    return exports.A3
end

exports.getB3 = function()
    return exports.B3
end

exports.getA4 = function()
    return exports.A4
end

exports.getB4 = function()
    return exports.B4
end

exports.getK1 = function()
    return exports.K1
end

exports.getK4 = function()
    return exports.K4
end

exports.getD1 = function()
    return exports.D1
end

exports.getD4 = function()
    return exports.D4
end

-- получить массив строковых индексов видеокамер в зависимости от АРМ для раскладки 3х3
-- нулевая камера в кабине противоположной той в которой находится АРМ
exports.Screen3x3_1 = {"K4",
				"A1","B1","A4",
				"A2","B2","B4",
				"A3","B3","D4"
			   }
exports.Screen3x3_2 = {"K1",
				"A1","B1","A4",
				"A2","B2","B4",
				"A3","B3","D1"
			   }
exports.get3x3 = function(arm_number)
	if arm_number == 1 then
	    return exports.Screen3x3_1
	else
		return exports.Screen3x3_2
	end
end

-- получить массив строковых индексов видеокамер в зависимости от АРМ для раскладки 2х3
-- нулевой и ндекс - пустая строка, для соответствия с документом презентации
exports.Screen2x3_1 = {"",
				"D1","A1",
					 "B2",
				"A2","B2","K1"
				}
exports.Screen2x3_2 = {"",
				"D4","A3",
					 "B3",
				"A4","B4","K4"
				}

exports.get2x3 = function(arm_number)
	if arm_number == 1 then
	    return exports.Screen2x3_1
	else
		return exports.Screen2x3_2
	end
end

-- получить массив строковых индексов видеокамер для раскладки 2х2 в зависимости от порядкового числа - индекса
exports.Screen2x2_1 = {
				"A1","B1",
				"A2","B2"
			   }

exports.Screen2x2_2 = {
				"A3","B3",
				"A4","B4"
			   }

exports.Screen2x2_3 = {
				"K1","D1",
				"K4","D4"
			   }

exports.get2x2 = function(idx)
    if idx == 1 then
		return exports.Screen2x2_1
    elseif idx == 2 then
		return exports.Screen2x2_2
    else 
		return exports.Screen2x2_3
    end
end

-- Функция проверки пароля для входа в настройки
exports.auth = function(password)
	if password == 999 then
		return true
	else
		return false
	end
end

-- Функции настроек экрана
-- Яркость по умолчанию
exports.brightness = 50

-- Контрастность по умолчанию
exports.contrast = 50

-- Сдвиг экрана по вертикали и горизонтали
exports.shift_x = 0
exports.shift_y = 0

-- Сжатие экрана по вертикали и горизонтали
exports.compress_x = 0
exports.compress_y = 0

-- Клавиши
exports.KEY_F1 = 1
exports.KEY_F2 = 2
exports.KEY_F3 = 3
exports.KEY_F4 = 4
exports.KEY_F5 = 5
exports.KEY_F6 = 6
exports.KEY_F12 = 12

exports.KEY_Num0 = 100
exports.KEY_Num1 = 101
exports.KEY_Num2 = 102
exports.KEY_Num3 = 103
exports.KEY_Num4 = 104
exports.KEY_Num5 = 105
exports.KEY_Num6 = 106
exports.KEY_Num7 = 107
exports.KEY_Num8 = 108
exports.KEY_Num9 = 109
exports.KEY_ENTER = 110

exports.KEY_ESC = 999

-- Состояния
exports.STATE_3X3 = 1
exports.STATE_SCHEMA = 2
exports.STATE_VIDEO_SETTINGS = 3
exports.STATE_SYSTEM_SETTINGS = 4
exports.STATE_LOGIN = 5
exports.STATE_2X2_1 = 61
exports.STATE_2X2_2 = 62
exports.STATE_2X2_3 = 63
exports.STATE_2X3_1 = 71
exports.STATE_2X3_2 = 72

-- Подсостояния настроек экрана
exports.SUBSTATE_VS_IDLE = 0
exports.SUBSTATE_VS_BRIGHTNES = 1
exports.SUBSTATE_VS_CONTRAST = 2
exports.SUBSTATE_VS_SHIFT_X = 3
exports.SUBSTATE_VS_SHIFT_Y = 4
exports.SUBSTATE_VS_COMPRESS_X = 5
exports.SUBSTATE_VS_COMPRESS_Y = 6

exports.substate = exports.SUBSTATE_VS_IDLE

-- Текущее состояние
exports.state = exports.STATE_3x3

-- Обработчик клавиатуры
exports.on_change_state = function (key_value)

	if key_value == exports.KEY_F1 then exports.onClickF1()
	elseif key_value == exports.KEY_F2 then exports.onClickF2()
	elseif key_value == exports.KEY_F3 then exports.onClickF3()
	elseif key_value == exports.KEY_F4 then exports.onClickF4()
	elseif key_value == exports.KEY_F5 then exports.onClickF5()
	elseif key_value == exports.KEY_F6 then exports.onClickF6()
	elseif key_value == exports.KEY_F6 then exports.onClickF12()
	elseif key_value == exports.KEY_Num0 then exports.onClickNum0()
	elseif key_value == exports.KEY_Num1 then exports.onClickNum1()
	elseif key_value == exports.KEY_Num2 then exports.onClickNum2()
	elseif key_value == exports.KEY_Num3 then exports.onClickNum3()
	elseif key_value == exports.KEY_Num4 then exports.onClickNum4()
	elseif key_value == exports.KEY_Num5 then exports.onClickNum5()
	elseif key_value == exports.KEY_Num6 then exports.onClickNum6()
	elseif key_value == exports.KEY_Num7 then exports.onClickNum7()
	elseif key_value == exports.KEY_Num8 then exports.onClickNum8()
	elseif key_value == exports.KEY_Num9 then exports.onClickNum9()
	elseif key_value == exports.KEY_ENTER then exports.onClickEnter()
	elseif key_value == exports.KEY_ESC then exports.onClickEsc()
    else
    -- клавиша не обрабатывается специально
    end
end

-- Функции отображения на экране
exports.show3x3 = function ()

end

exports.showSchema = function ()

end

exports.showVideoSettings = function ()
    exports.focus_text_brightess()
end

exports.showSystemSetings = function ()

end

exports.showLogin = function ()
	exports.password = ""
    exports.edit_new_value = ""
end

exports.show2x2 = function ()

end

exports.show2x3 = function ()

end

-- Обработчики нажатия клавиш
exports.onClickF1 = function ()
	if exports.state == exports.STATE_3X3 then
		exports.state = exports.STATE_SCHEMA
		exports.showSchema()
		return exports.STATE_SCHEMA
	else
		exports.state = exports.STATE_3X3
		exports.show3x3()
		return exports.STATE_3X3
	end
end

exports.onClickF2 = function ()
	if exports.state == exports.STATE_VIDEO_SETTINGS then
		return exports.STATE_VIDEO_SETTINGS								
	else
		exports.state = exports.STATE_VIDEO_SETTINGS
		exports.showVideoSettings()
		return exports.STATE_VIDEO_SETTINGS
	end
end

exports.onClickF3 = function ()
	if exports.state == exports.STATE_SYSTEM_SETTINGS then
		return exports.STATE_SYSTEM_SETTINGS
	else
		exports.state = exports.STATE_LOGIN
		exports.showLogin()
		return exports.STATE_LOGIN
	end
end

exports.onClickF4 = function ()
	if exports.state == exports.STATE_2X2_1 then
		exports.state = exports.STATE_2X2_2
		exports.show2x2()
		return exports.STATE_2X2_2
	elseif exports.state == exports.STATE_2X2_2 then
		exports.state = exports.STATE_2X2_3
		exports.show2x2()
		return exports.STATE_2X2_3
	else
		exports.state = exports.STATE_2X2_1
		exports.show2x2()
		return exports.exports.STATE_2X2_1
	end
end

exports.onClickF5 = function ()
	if exports.state == exports.STATE_2X3_1 then
		exports.state = exports.STATE_2X3_2
		exports.show2x3()
		return exports.STATE_2X3_2
	else
		exports.state = exports.STATE_2X3_1
		exports.show2x3()
		return exports.exports.STATE_2X3_1
	end
end


exports.onClickF6 = function ()
	if exports.state == exports.STATE_3X3 then
		exports.state = exports.STATE_SCHEMA
		exports.showSchema()
		return exports.STATE_SCHEMA
	else
		exports.state = exports.STATE_3X3
		exports.show3x3()
		return exports.STATE_3X3
	end
end

exports.onClickF12 = function ()
	-- TODO: shutdown
end

exports.onClickEnter = function ()
	if exports.state == exports.STATE_LOGIN then
        exports.login_ClickEnter()
    elseif exports.state == exports.STATE_VIDEO_SETTINGS then
        exports.vs_ClickEnter()
	end
end

exports.vs_ClickEnter = function ()

    if exports.substate == exports.SUBSTATE_VS_BRIGHTNES then
        exports.unfocus_text_brightess()
        exports.focus_text_contrast()
    elseif exports.substate == exports.SUBSTATE_VS_CONTRAST then
        exports.unfocus_text_contrast()
        exports.focus_text_shift_x()
    elseif exports.substate == exports.SUBSTATE_VS_SHIFT_X then
        exports.unfocus_text_shift_x()
        exports.focus_text_shift_y()
    elseif exports.substate == exports.SUBSTATE_VS_SHIFT_Y then
        exports.unfocus_text_shift_y()
        exports.focus_text_compress_x()
    elseif exports.substate == exports.SUBSTATE_VS_COMPRESS_X then
        exports.unfocus_text_compress_x()
        exports.focus_text_compress_y()
    elseif exports.substate == exports.SUBSTATE_VS_COMPRESS_Y then
        exports.unfocus_text_compress_y()
        exports.focus_text_brightess()
    else
        -- что то пошло не так
    end
end

exports.save_brightness = function ()
    if exports.edit_new_value ~= "" then
       exports.brightness = exports.edit_new_value
    else
       exports.brightness = exports.edit_old_value 
    end
end

exports.save_contrast = function ()
    if exports.edit_new_value ~= "" then
        exports.contrast = exports.edit_new_value
    else
        exports.contrast = exports.edit_old_value 
    end
end

exports.save_shift_x = function ()
    if exports.edit_new_value ~= "" then
        exports.shift_x = exports.edit_new_value
    else
        exports.shift_x = exports.edit_old_value 
    end
end

exports.save_shift_y = function ()
    if exports.edit_new_value ~= "" then
        exports.shift_y = exports.edit_new_value
    else
        exports.shift_y = exports.edit_old_value 
    end
end

exports.save_compress_x = function()
    if exports.edit_new_value ~= "" then
        exports.compress_x = exports.edit_new_value
    else
        exports.compress_x = exports.edit_old_value 
    end
end

exports.save_compress_y = function()
    if exports.edit_new_value ~= "" then
        exports.compress_y = exports.edit_new_value
    else
        exports.compress_y = exports.edit_old_value 
    end
end


exports.login_ClickEnter = function ()
    exports.password = exports.edit_new_value
	if exports.auth(exports.password) then
		exports.state = exports.STATE_SYSTEM_SETTINGS
		exports.showSystemSetings()
    	return exports.STATE_SYSTEM_SETTINGS
	else
		exports.showLogin()
		return exports.STATE_LOGIN
	end
end

exports.onClickNum0 = function ()
    exports.edit_new_value = exports.edit_new_value .. "0"
end

exports.onClickNum1 = function ()
    exports.edit_new_value = exports.edit_new_value .. "1"
end

exports.onClickNum2 = function ()
    exports.edit_new_value = exports.edit_new_value .. "2"
end

exports.onClickNum3 = function ()
    exports.edit_new_value = exports.edit_new_value .. "3"
end

exports.onClickNum4 = function ()
    exports.edit_new_value = exports.edit_new_value .. "5"
end

exports.onClickNum5 = function ()
    exports.edit_new_value = exports.edit_new_value .. "5"
end

exports.onClickNum6 = function ()
    exports.edit_new_value = exports.edit_new_value .. "6"
end

exports.onClickNum7 = function ()
    exports.edit_new_value = exports.edit_new_value .. "7"
end

exports.onClickNum8 = function ()
    exports.edit_new_value = exports.edit_new_value .. "8"
end

exports.onClickNum9 = function ()
    exports.edit_new_value = exports.edit_new_value .. "9"
end

exports.onClickEsc = function ()
    exports.edit_new_value = exports.edit_old_value
    exports.update()
end

-- Input functions and variable
-- Функция обновляет поля ввода
exports.update = function()
    if exports.state == exports.STATE_LOGIN then
        exports.update_text_login()
    else
        if exports.substate == exports.SUBSTATE_VS_BRIGHTNES then
            exports.update_text_brightess()
        elseif exports.substate == exports.SUBSTATE_VS_CONTRAST then
            exports.update_text_contrast()
        elseif exports.substate == exports.SUBSTATE_VS_SHIFT_X then
            exports.update_text_shift_x()
        elseif exports.substate == exports.SUBSTATE_VS_SHIFT_Y then
            exports.update_text_shift_y()
        elseif exports.substate == exports.SUBSTATE_VS_COMPRESS_X then
            exports.update_text_compress_x()
        elseif exports.substate == exports.SUBSTATE_VS_COMPRESS_Y then
            exports.update_text_compress_y()
        else
            -- что то пошло не так
        end
    end
end

exports.update_text_brightess = function()
    -- TODO: change tekUI widget обновить текст значением exports.edit_new_value
end

exports.focus_text_brightess = function()
    exports.edit_old_value = "" .. exports.brightness
    exports.edit_new_value = ""
    exports.substate = SUBSTATE_VS_BRIGHTNES
end

exports.unfocus_text_brightess = function()
    exports.save_brightness()
    -- TODO: change tekUI widget
end

exports.update_text_contrast = function()
    -- TODO: change tekUI widget обновить текст значением exports.edit_new_value
end

exports.focus_text_contrast = function()
    exports.edit_old_value = "" .. exports.contrast
    exports.edit_new_value = ""
    exports.substate = exports.SUBSTATE_VS_CONTRAST
end

exports.unfocus_text_contrast = function()
    exports.save_contrast()
    -- TODO: change tekUI widget
end

exports.update_text_shift_x = function()
    -- TODO: change tekUI widget обновить текст значением exports.edit_new_value
end

exports.focus_text_shift_x = function()
    exports.edit_old_value = "" .. exports.shift_x
    exports.edit_new_value = ""
    exports.substate = SUBSTATE_VS_SHIFT_X
end

exports.unfocus_text_shift_x = function()
    exports.save_shift_x()
    -- TODO: change tekUI widget
end

exports.update_text_shift_y = function()
    -- TODO: change tekUI widget обновить текст значением exports.edit_new_value
end

exports.focus_text_shift_y = function()
    exports.edit_old_value = "" .. exports.shift_y
    exports.edit_new_value = ""
    exports.substate = SUBSTATE_VS_SHIFT_Y
end

exports.unfocus_text_shift_y = function()
    exports.save_shift_y()
    -- TODO: change tekUI widget
end

exports.update_text_compress_x = function()
    -- TODO: change tekUI widget обновить текст значением exports.edit_new_value
end

exports.focus_text_compress_x = function()
    exports.edit_old_value = "" .. exports.compress_x
    exports.edit_new_value = ""
    exports.substate = SUBSTATE_VS_COMPRESS_X
end

exports.unfocus_text_compress_x = function()
    exports.save_compress_x()
    -- TODO: change tekUI widget
end

exports.update_text_compress_y = function()
    -- TODO: change tekUI widget обновить текст значением exports.edit_new_value
end

exports.focus_text_compress_y = function()
    exports.edit_old_value = "" .. exports.compress_y
    exports.edit_new_value = ""
    exports.substate = SUBSTATE_VS_COMPRESS_Y
end

exports.unfocus_text_compress_y = function()
    exports.save_compress_y()
    -- TODO: change tekUI widget
end

exports.update_text_login = function()
    -- TODO: change tekUI widget обновить текст значением exports.edit_new_value
end

exports.parse = function(json_string)
    exports.tbl = json.decode(json_string)
    table.foreach(exports.tbl,print)

    exports.isDebug = exports.tbl.isDebug
    exports.A1 = exports.tbl.A1
	exports.B1 = exports.tbl.B1
	exports.A2 = exports.tbl.A2
	exports.B2 = exports.tbl.B2
	exports.A3 = exports.tbl.A3
	exports.B3 = exports.tbl.B3
	exports.A4 = exports.tbl.A4
	exports.B4 = exports.tbl.B4
	exports.K1 = exports.tbl.K1
	exports.K4 = exports.tbl.K4
	exports.D1 = exports.tbl.D1
	exports.D4 = exports.tbl.D4
	exports.Screen3x3_1 = exports.tbl.Screen3x3_1
	exports.Screen3x3_2 = exports.tbl.Screen3x3_2
	exports.Screen2x3_1 = exports.tbl.Screen2x3_1
	exports.Screen2x3_2 = exports.tbl.Screen2x3_2
	exports.Screen2x2_1 = exports.tbl.Screen2x2_1
	exports.Screen2x2_2 = exports.tbl.Screen2x2_2
	exports.Screen2x2_3 = exports.tbl.Screen2x2_3
	exports.brightness = exports.tbl.brightness
	exports.contrast = exports.tbl.contrast
	exports.shift_x = exports.tbl.shift_x
	exports.shift_y = exports.tbl.shift_y
	exports.compress_x = exports.tbl.compress_x
	exports.compress_y = exports.tbl.compress_y
	exports.KEY_F1 = exports.tbl.KEY_F1
	exports.KEY_F2 = exports.tbl.KEY_F2
	exports.KEY_F3 = exports.tbl.KEY_F3
	exports.KEY_F4 = exports.tbl.KEY_F4
	exports.KEY_F5 = exports.tbl.KEY_F5
	exports.KEY_F6 = exports.tbl.KEY_F6
	exports.KEY_F12 = exports.tbl.KEY_F12
	exports.KEY_Num0 = exports.tbl.KEY_Num0
	exports.KEY_Num1 = exports.tbl.KEY_Num1
	exports.KEY_Num2 = exports.tbl.KEY_Num2
	exports.KEY_Num3 = exports.tbl.KEY_Num3
	exports.KEY_Num4 = exports.tbl.KEY_Num4
	exports.KEY_Num5 = exports.tbl.KEY_Num5
	exports.KEY_Num6 = exports.tbl.KEY_Num6
	exports.KEY_Num7 = exports.tbl.KEY_Num7
	exports.KEY_Num8 = exports.tbl.KEY_Num8
	exports.KEY_Num9 = exports.tbl.KEY_Num9
	exports.KEY_ENTER = exports.tbl.KEY_ENTER
	exports.KEY_ESC = exports.tbl.KEY_ESC
end

exports.init = function()
	exports.body = ""
    for line in io.lines("settings.json") do 
		exports.body = exports.body .. line
	end
	exports.parse(exports.body)
	print("Init: done")
end

return exports

