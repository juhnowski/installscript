local serial = require 'modules.serial'

return {
  open = function(self,port,speed)
    self.f=serial.open(port,speed or 115200)
    self.f:write('CMDON\r')
    local l = self.f:read()
    if l~='\r' then
      self.f:read()
    end
  end,

  get = function(self,what)
    self.f:write('$M GET '..what..'\r')
    return self.f:read()
  end,

  close = function(self)
    self.f:close()
  end,

  coords = function(self)
    local data = self:get('COORD')
    local t = {}
    for i in data:gmatch('([^,]+)') do
      table.insert(t,i)
    end

    if #t<12 or t[2]=='ERROR' then
      return null
    else
      return {
        date = '20'..t[3]:sub(5,6)..'-'..t[3]:sub(3,4)..'-'..t[3]:sub(1,2),
        time = t[4]:sub(1,2)..':'..t[4]:sub(3,4)..':'..t[4]:sub(5,6),
        lat = tonumber(t[5]),
        lon = tonumber(t[6]),
        sat = tonumber(t[7]),
        quality = tonumber(t[8]),
        hdop = tonumber(t[9]),
        speed = tonumber(t[10]),
        course = tonumber(t[11]),
        altitude = tonumber(t[12])
      }
    end
  end
}