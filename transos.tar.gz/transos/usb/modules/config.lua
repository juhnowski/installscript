local ConfigData = require('modules.models.config'):all()

local Config = {
  Serial = {
    port = 'ACM1',
    speed = 115200
  }
}

setmetatable(Config,{__index = function(table,key) return {_empty=true} end})

for i,v in pairs(ConfigData) do
  local modulename,paramname
  if i:find('.',1,true) then
    modulename = i:sub(1,i:find('.',1,true)-1)
    paramname = i:sub(i:find('.',1,true)+1,-1)
  else
    modulename = ''
    paramname = i
  end

  if Config[modulename]._empty then
    Config[modulename] = {}
  end

  if type(Config[i]) == 'string' then
    Config[modulename][i] = tostring(v.data.value)
  elseif type(Config[i]) == 'number' then
    Config[modulename][i] = tonumber(v.data.value)
  elseif type(Config[i]) == 'boolean' then
    Config[modulename][i] = (type(v.data.value) == 'boolean' and v.data.value) or tonumber(v.data.value)==1 or tostring(v.data.value)=='true'
  end
end

return Config