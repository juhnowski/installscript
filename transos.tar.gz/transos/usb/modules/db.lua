box.cfg{
  snapshot_period=3600,
  snapshot_count=3,
  log_level=3
}

if not box.space.config then
  local config = box.schema.space.create('config')
  config:create_index('primary',{unique = true, parts = {1, 'STR'}})
end


if not box.space.coords then
  local coords = box.schema.space.create('coords')
  coords:create_index('primary',{unique = true, parts = {1,'NUM'}})
end

Config = require('modules.config')

