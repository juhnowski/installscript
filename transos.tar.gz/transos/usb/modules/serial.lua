return {
  open = function(port,speed)
    local dev = '/dev/tty'..port
    io.popen('stty -F '..dev..' -icanon')
    io.popen('stty -F '..dev..' raw')
    io.popen('stty -F '..dev..' '..speed)
    io.popen('stty -F '..dev..' min 0 time 100')
    return io.open (dev, 'r+b')
  end
}