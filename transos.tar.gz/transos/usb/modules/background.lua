local fiber = require 'fiber'
local Config = require 'modules.config'
local Coords = require 'modules.models.coords'
local Statt = require 'modules.statt'

fiber.create(function()
  Statt:open(Config.Serial.port,Config.Serial.speed)
  local coords = Statt:coords()
  local c = Coords:new(nil,coords)
  c:save()
  Statt.close()
  fiber.sleep(1)
end)