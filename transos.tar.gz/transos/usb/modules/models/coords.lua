local Model = require 'modules.models.model'

local Coords = { space = 'coords' }
Coords.__index = Coords
setmetatable(Coords, {__index = Model} )

return Coords