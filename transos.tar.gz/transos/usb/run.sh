#!/bin/sh

killall -q -r tarantool

tarantool init.lua  > log/error.log 2>&1 &

