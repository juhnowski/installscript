#!/usr/bin/python2
# coding: utf-8
 
import serial, time

def connect():
    """Функция коннекта"""
    while True:
        try:
            print 'Соединяемся'
            p = serial.Serial('/dev/ttyACM0', 115200, timeout = 10)

            # После каждого удачного открытия порта пробуем переходить в командный режим.
            # Если прибор в командном режиме то он вернет '\r\n', если в терминальном
            # прибор вернет две строки, которые необходимо вычитать.
            p.write('CMDON\r')
            line = p.readline()
            if line != '\r\n':
                line = p.readline()
                print 'Вошли в командный режим'

            return p

        except serial.serialutil.SerialException:
            time.sleep(1)

try:

    print 'Старт'
    port = connect()
    cnt = 10

    while True:
        try:
            # Начало основного цикла.

            cnt += 1
            if cnt >= 10:
                port.write('$M GET RFID\r')
                line = port.readline()
                print line,
                cnt = 0

            port.write('$M GET COORD\r')
            line = port.readline()
            print line,
            #time.sleep(0.5)

            port.write('$M GET DUT\r')
            line = port.readline()
            print line,
            time.sleep(1)

            # Конец основного цикла.

        except serial.serialutil.SerialException:
            # Закрываем порт, ждём пол секунды пока завершится действие.
            port.close()
            time.sleep(0.5)
            # Соединяемся.
            port = connect()
            cnt = 10

# При получении исключения - прерывание от клавиатуры выходим.
except KeyboardInterrupt:
    try:
        # При каждом выходе пытаемся выйти в терминальный режим и закрыть порт.
        port.write('EXIT\r')
        port.close()
    except:
        pass

print '\r\nВыход'

