#include <lua.h>
#include <lauxlib.h>
#include <lualib.h>

static int
parseHeader(struct lua_State *L)
{
  char buf[4];
  // extract arg
  const char *header = lua_tolstring(L,-1,0);//Извлекаем из вершины стека функции параметр.
  // local b1,payLoadType,SSRC,payLoadLen,reserved = pickle.unpack('bbnNN',header)
  unsigned char b1 = header[0];
  unsigned char payLoadType = header[1];
  buf[0] = header[3]; buf[1] = header[2];
  unsigned short SSRC = *((short*)&buf[0]);
  buf[0] = header[7]; buf[1] = header[6]; buf[2] = header[5]; buf[3] = header[4]; 
  unsigned int payLoadLen = *((int*)&buf[0]);

  lua_pushinteger(L,payLoadType);//Заталкиваем в стек функции параметр.
  lua_pushinteger(L,payLoadLen);
  lua_pushinteger(L,SSRC);

  // local head = {}
  lua_newtable(L);//Создание таблицы и помещение её в стек функции.
  // head.V = b1 % 4
  char tmp = b1 % 4;
  lua_pushinteger(L,tmp);
  lua_setfield(L,-2,"V");
  // b1 = (b1 - head.V) / 4
  b1 = (b1 - tmp) >> 2;
  // head.P = b1 % 2
  tmp = b1 % 2;
  lua_pushinteger(L,tmp);
  lua_setfield(L,-2,"P");
  // b1 = (b1 - head.P) / 2
   b1 = (b1 - tmp) >> 1;
  // head.M = b1 % 2
  tmp = b1 % 2;
  lua_pushinteger(L,tmp);
  lua_setfield(L,-2,"M");
  // b1 = (b1 - head.M) / 2
  b1 = (b1 - tmp) / 2;
  // head.CSRCCount = b1
  lua_pushinteger(L,b1);
  lua_setfield(L,-2,"CSRCCount");
  //return payLoadType,payLoadLen,SSRC,head
  return 4; // number of results
}


static int
makeHeader(struct lua_State *L)
{
// args: payLoadType, payLoad
  size_t l;
  const char* payLoad = lua_tolstring(L,-1,&l);
  lua_pop(L,1);

  short payLoadType = (short)lua_tointeger(L,-1);
  lua_pop(L,1);

//  return pickle.pack('bbnNN',0,0,payLoadType,#payLoad,0)
  unsigned char ret[12];
  ret[0] = 0;
  ret[1] = 0;
  ret[2] = ((char*)&payLoadType)[1];
  ret[3] = ((char*)&payLoadType)[0];
  ret[4] = ((char*)&l)[3];
  ret[5] = ((char*)&l)[2];
  ret[6] = ((char*)&l)[1];
  ret[7] = ((char*)&l)[0];
  ret[8] = 0;
  ret[9] = 0;
  ret[10] = 0;
  ret[11] = 0;

  lua_pushlstring(L, &ret[0], 12);

  return 1;
}

static int
parseH264(struct lua_State *L)
{
// arg: payLoad
  size_t l_payLoad;
  const char* payLoad = lua_tolstring(L,-1,&l_payLoad);
  lua_pop(L,1);

//  local z, ch, d, c, l, res, off, short1, long1, ts = pickle.unpack('bbbbssssii',string.sub(payLoad,1,20))
  unsigned char z = payLoad[0];
  unsigned char ch = payLoad[1];
  unsigned char d = payLoad[2];
  unsigned char c = payLoad[3];
  unsigned short l = *(short*)&payLoad[4];
  unsigned short res = *(short*)&payLoad[6];
  unsigned short off = *(short*)&payLoad[8];
  unsigned short short1 = *(short*)&payLoad[10];
  unsigned int long1 = *(int*)&payLoad[12];
  unsigned int ts = *(int*)&payLoad[16];

//  local valid = (z == 0 and string.char(d,c)=='dc')
  int valid = z == 0 && d == 'd' && c=='c';

//  local channel, data
//  if valid then
//    channel = string.char(ch)
//    data = payLoad:sub(off+12+1,l+off+12+1)
//  end

  char channel[1];
  const char *data;
  if(valid) {
    channel[0] = ch;
    data = &payLoad[off+12];
  }
  else {
    data = "";
    l = 0;
  }

//  local incomplete = l + off + 12  - #payLoad
  int incomplete = l + off + 12  - l_payLoad;

//  return valid, channel, ts, data, incomplete
  lua_pushinteger(L, valid);
  lua_pushlstring(L, channel, 1);
  lua_pushinteger(L, ts);
  lua_pushlstring(L, data, l);
  lua_pushinteger(L, incomplete);

  return 5;
}

LUA_API int
luaopen_c_n9m(lua_State *L)
{
  static const struct luaL_reg reg[] = {
    {"parseHeader", parseHeader},
    {"makeHeader", makeHeader},
    {"parseH264", parseH264},
    {NULL, NULL}
  };

  luaL_register(L, "_n9m", reg);
  return 1;
}

