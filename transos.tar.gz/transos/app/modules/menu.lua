#!/usr/bin/env lua5.1

local ui = require "tek.ui"
local exec = require "tek.lib.exec"
local visual = require "tek.lib.visual"
local MainScreen = require("pages.MainScreen");
local ManagePower = require("pages.ResetOff");
local AutoInfo = require("pages.AutoInfo");
local SetRoute = require("pages.SetRoutePtr");
local StreamPass = require("pages.SystemCountStreamPass");
local MainMenu = require("pages.mainMenu1");
local messages = require("pages.Messages");
local set = require("pages.set");
local InfoPanel = require("pages.InfoPanel");
local SetKeymap = require("pages.SetKeymap");
local StateTS = require("pages.StateTS");
local tableFrame = {
	MainScreen, 
	ManagePower, 
	AutoInfo,
	SetRoute,
	StreamPass,
	MainMenu,
	messages,
	set,
	InfoPanel,
	SetKeymap,
	StateTS
};
i = 1;
--local Video = require("canvas")

local PPM_BackGround = ui.loadImage(ui.ProgDir ..  "/graphics/imageFile/Background/background2.ppm")

local BMP_ArrowLeft = ui.loadImage(ui.ProgDir ..  "/graphics/imageFile/arrow_left.ppm")
local BMP_MainScreen = ui.loadImage(ui.ProgDir .. "/graphics/imageFile/main_screen.ppm")
local BMP_Menu = ui.loadImage(ui.ProgDir .. "/graphics/imageFile/menu.ppm")
local BMP_Comments = ui.loadImage(ui.ProgDir .. "/graphics/imageFile/comments.ppm")
local BMP_Video = ui.loadImage(ui.ProgDir .. "/graphics/imageFile/video.ppm") 
local BMP_Volume = ui.loadImage(ui.ProgDir .. "/graphics/imageFile/volume.ppm")
local BMP_Settings = ui.loadImage(ui.ProgDir .. "/graphics/imageFile/settings.ppm")
local BMP_ArrowRight = ui.loadImage(ui.ProgDir .. "/graphics/imageFile/arrow_right.ppm")


local app = ui.Application:new
{
--	Id = "the-application",
	Children =
	{
		ui.Window:new
		{
			Title = "Canvas and Scrollgroup",
			HideOnEscape = true,
			Orientation = "vertical",
			FullScreen = true,
			MaxWidth = 1024,
			--Id = "the-window",
			Children =
			{
				ui.ScrollGroup:new
				{
					HSliderMode = "auto",
					VSliderMode = "auto",
					Child = ui.Canvas:new
					{
						--Style = "background-image: url(/root/user-dm/Lua_project/graphics/imageFile/Background/background2.ppm)",
						Style = "background-image: url(graphics/imageFile/Background/background2.ppm)",
						--Style = "background-color: #678",
						--EraseBG = false;
						UseChildBG = false,
						AutoWidth = true,
						AutoHeight = true,
						Id = "the-canvas",
					}
				},
				ui.Group:new
                                {
                                        SameSize = false,
                                        Children =
                                        {
						ui.ImageWidget:new
                                                {
                                                        Height = "auto",
                                                        Mode = "button",
							Width = 100,
                                                        Image = BMP_ArrowLeft,
							onClick = function(self)
								self:getById("the-canvas"):setValue("Child", tableFrame[i]);
								i = i + 1;
								if i == #tableFrame + 1 then
									i = 1;
								end
                                                        end
                                                },
						ui.ImageWidget:new
                                                {
                                                        Height = "auto",
                                                        Mode = "button",
							Width = 100,
                                                        Image = BMP_MainScreen,
                                                        onClick = function(self)
                                                                self:getById("the-canvas"):setValue("Child",  MainScreen);
                                                        end
                                                },
						ui.ImageWidget:new
                                                {
                                                        Height = "auto",
                                                        Mode = "button",
							Width = 100,
                                                        --Style = [[
                                                                --[[background-color: transparent;
                                                                margin: 10;
                                                                padding: 4;
                                                                border-width: 10;
                                                                border-focus-width: 6;
                                                                min-width: 60;--]]
                                                        --]],
                                                        Image = BMP_Menu,
                                                        onClick = function(self)
                                                                self:getById("the-canvas"):setValue("Child", MainMenu);
                                                        end
                                                },
						ui.ImageWidget:new
                                                {
                                                        Height = "auto",
                                                        Mode = "button",
							Width = 150,
                                                        --Style = [[
                                                                --[[background-color: transparent;
                                                                margin: 10;
                                                                padding: 4;
                                                                border-width: 10;
                                                                border-focus-width: 6;
                                                                min-width: 60;--]]
                                                        --]],
                                                        Image = BMP_Comments,
                                                        onClick = function(self)
                                                                self:getById("the-canvas"):setValue("Child", messages);
                                                        end
                                                },
						ui.ImageWidget:new
                                                {
                                                        Height = "auto",
                                                        Mode = "button",
                                                        Width = 150,
                                                        --Style = [[
                                                                --[[background-color: transparent;
                                                                margin: 10;
                                                                padding: 4;
                                                                border-width: 10;
                                                                border-focus-width: 6;
                                                                min-width: 60;--]]
                                                        --]],
                                                        Image = BMP_Video,
                                                        onClick = function(self)
                                                                --self:getById("the-canvas"):setValue("Child", false);
								--self:getById("the-canvas"):setValue("Child", Video);
								--Style = "background-color: #000"
--								exec.run("canvas.lua");
								self:getById("the-canvas"):setValue("Child", false);
								--exec.sleep(1000);
								os.execute("./fbff -u -sx -a - SampleVideo_360x240_1mb.mp4");
                                                        end
                                                },
						ui.ImageWidget:new
                                                {
                                                        Height = "auto",
                                                        Mode = "button",
                                                        Width = 150,
                                                        --Style = [[
                                                                --[[background-color: transparent;
                                                                margin: 10;
                                                                padding: 4;
                                                                border-width: 10;
                                                                border-focus-width: 6;
                                                                min-width: 60;--]]
                                                        --]],
                                                        Image = BMP_Volume,
                                                        onClick = function(self)
								os.execute("killall -9 fbff");
                                                                --self:getById("the-canvas"):setValue("Child", Frame3);
                                                        end
                                                },
						ui.ImageWidget:new
                                                {
                                                        Height = "auto",
                                                        Mode = "button",
                                                        Width = 150,
                                                        --Style = [[
                                                                --[[background-color: transparent;
                                                                margin: 10;
                                                                padding: 4;
                                                                border-width: 10;
                                                                border-focus-width: 6;
                                                                min-width: 60;--]]
                                                        --]],
                                                        Image = BMP_Settings,
                                                        onClick = function(self)
                                                                self:getById("the-canvas"):setValue("Child", set);
                                                        end
                                                },
						ui.ImageWidget:new
                                                {
                                                        Height = "auto",
                                                        Mode = "button",
							Width = 150,	
                                                        Image = BMP_ArrowRight
                                                }
                                        }
                                }
			}
		}
	}

}

app:run()
app:hide()
app:cleanup()
