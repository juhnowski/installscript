return {
  date = {
    iso2lua = function(isodate)
      return os.time({year=isodate:sub(1,4),month=isodate:sub(6,7),day=isodate:sub(9,10),
                          hour=isodate:sub(12,13),min=isodate:sub(15,16),sec=isodate:sub(18,19)})
    end,

    lua2iso = function(luadate)
      return os.date('%Y-%m-%d %H:%M:%S',luadate)
    end
  }
}