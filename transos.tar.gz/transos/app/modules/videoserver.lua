Config = require 'modules.config'

log = require 'log'
json=require 'json'
socket = require 'socket'
fio = require 'fio'
clock = require 'clock'
fiber = require 'fiber'

n9m = require('modules.n9m')
Stream = require('modules.models.stream')

socket.tcp_server('0.0.0.0', Config.OrbitaX.video_server_port, function(s)
  local udp = socket('AF_INET', 'SOCK_DGRAM', 'udp')
  --local tcp = socket('AF_INET', 'SOCK_STREAM', 'tcp');
  local port, streamId
  local n = 0
  local incomplete = 0
  local channel, ts
  local pts = 0
  local prt = 0
  local downloadfile
  while true do
    local header
    header = s:read(12);
    if header == "" or header == nil then
      if downloadfile then
        downloadfile:close()
        local stream = Stream:load(streamId)
        stream.data.completed = true
        stream:save()
      end

      break
    end

    local payLoadType,payLoadLen,ssrc = n9m.parseHeader(header)
    local payLoad = s:read(payLoadLen)

    if payLoadType == 0 then -- JSON
      log.info("(video) JSON received: " .. payLoad)
	print("(video) JSON received: " .. payLoad);

      local data = json.decode(payLoad)

      if data.OPERATION == 'CREATESTREAM' then
        local response = json.encode{MODULE='CERTIFICATE',OPERATION='CREATESTREAM',RESPONSE={ERRORCAUSE='',ERRORCODE=0},SESSION=data.SESSION}

        local stream = Stream:by('name',data.PARAMETER.STREAMNAME)
        if #stream == 1 then
          streamId = stream[1].id
          port = stream[1].data.port
	--port = stream[1].data.webm_port;
        --print("webm_port = " .. stream[1].data.webm_port);
	--port = 9001
          log.info("(video) sending response: " .. response)
	print("(video) sending response: " .. response);
          s:write(n9m.makeHeader(0,response) .. response)
        else
          log.info("(video) stream not found: " .. data.PARAMETER.STREAMNAME)
	print("(video) stream not found: " .. data.PARAMETER.STREAMNAME);
        end
      end

    elseif payLoadType == 2 or payLoadType == 4 then -- H264 
      log.info("(video) h.264 data received")
	print("(video) h.264 data received");
      local valid, data
      local stream = Stream:load(streamId)

      if stream.data.force_stop then
        log.info("(video) force stop")
	print("(video) force stop");
        stream.data.force_stop = nil
        stream:save()
--        s:close() error "attempt to use closed socket"
        return
      end

      stream.data.last_source_data = os.time()
      if not stream.data.source_online then
        stream.data.last_client_query = os.time()
      end
      stream.data.source_online = true
      stream:save()
      if incomplete > 0 then
        valid, data, incomplete = true, payLoad, incomplete - #payLoad
      else
        valid, channel, ts, data, incomplete = n9m.parseH264(payLoad)
      end

      if valid and channel ~= 4 then
        if stream.data.stream_type == 'archive' then
          if pts > 0 then
            if (ts - pts) > (clock.realtime()-prt)*1000 then
              local sleep = (ts - pts)/1000 - (clock.realtime()-prt)
              if sleep>1 then
                sleep = 1
              end
              fiber.sleep(sleep)
            end
          end

          pts = ts
          prt = clock.realtime()
        end
        udp:sendto('127.0.0.1', port, data)
	--tcp:sendto('127.0.0.1', port, data);
      end

--    if valid and channel == '4' then
      if false then
        local f = fio.open('/root/tarantool_sandbox/video/' .. string.format('%04d',n), {'O_CREAT','O_RDWR'})
        f:write(data)
        f:close()
        n = n + 1
      end
    elseif payLoadType == 3 then -- video file
      log.info('(video) video file received')
	print('(video) video file received');
      local stream = Stream:load(streamId)
      local valid, data

      if stream.data.stream_type == 'download' then
        if not downloadfile then
          local d = ''
          for dir in string.gmatch( fio.dirname(stream.data.file_name), "[^/]+") do
            d = d .. '/' .. dir
            if not fio.stat(d) then
              fio.mkdir(d)
            end
          end
          downloadfile = fio.open(stream.data.file_name, {'O_CREAT','O_RDWR'})
        end

        stream.data.last_source_data = os.time()
        stream.data.source_online = true
        stream:save()

        while true do
          if incomplete > 0 then
            valid, data, incomplete = true, payLoad, incomplete - #payLoad
          else
            valid, channel, ts, data, incomplete = n9m.parseH264(payLoad)
          end

log.error('L=%d D=%d I=%d',#payLoad,data and #data or 0,incomplete)

          if valid and channel ~= 4 then
            downloadfile:write(data)
          end

          if valid and incomplete<0 then
            payLoad = payLoad:sub(#payLoad+incomplete+1)
            incomplete = 0
          else
            break
          end
        end
          
      else
        log.error('(video) stream not found!')
	print('(video) stream not found!');
        return
      end
    else
      log.info('(video) ' .. payLoadType .. " received")
	print('(video) ' .. payLoadType .. " received");
    end

  end
end)
