local ui = require("tek.ui")

--MENU
local BMP_MMenu = ui.loadImage(ui.ProgDir ..  "/graphics/imageFile/Menu/menu.ppm")
local BMP_Videoregistrator = ui.loadImage(ui.ProgDir ..  "/graphics/imageFile/Menu/videoregistrator.ppm")
local BMP_User = ui.loadImage(ui.ProgDir ..  "/graphics/imageFile/Menu/user.ppm")

local MainMenu = ui.Group:new
{
        Layout = "fixed",
        Style = "background-image: url(graphics/imageFile/Background/background2.ppm)",
        Children =
	{
		ui.Text:new
		{
			Text = "Меню",
			Class = "button",
        		Style = [[
		                font: ui-huge;
                		background-color: #cc0000;
		                color: #fff;
                		width: 1000;
		                height: 700;
                		margin: 500;
				text-align: "center";
         		]]
		}
	}
}

return MainMenu
