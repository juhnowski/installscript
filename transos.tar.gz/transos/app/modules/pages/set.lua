local ui = require("tek.ui")

--MENU
local PPM_mainScreen = ui.loadImage(ui.ProgDir ..  "/graphics/imageFile/Set/main_screen.ppm")
local PPM_videoReg = ui.loadImage(ui.ProgDir ..  "/graphics/imageFile/Set/video_reg.ppm")
local PPM_autoInfo = ui.loadImage(ui.ProgDir ..  "/graphics/imageFile/Set/auto_info.ppm")
local PPM_askp = ui.loadImage(ui.ProgDir ..  "/graphics/imageFile/Set/askp.ppm")
local PPM_infoPanel = ui.loadImage(ui.ProgDir ..  "/graphics/imageFile/Set/info_panel.ppm")
local PPM_messages = ui.loadImage(ui.ProgDir ..  "/graphics/imageFile/Set/messages.ppm")
local PPM_users = ui.loadImage(ui.ProgDir ..  "/graphics/imageFile/Set/users.ppm")
local PPM_menuSet = ui.loadImage(ui.ProgDir ..  "/graphics/imageFile/Set/menu_set.ppm")
local PPM_updatePO = ui.loadImage(ui.ProgDir ..  "/graphics/imageFile/Set/update_po.ppm")
local PPM_header = ui.loadImage(ui.ProgDir ..  "/graphics/imageFile/Set/set.ppm")

local MenuSet = ui.Group:new
{
        Layout = "fixed",
        Style = "background-image: url(graphics/imageFile/Background/background2.ppm)",
        Children =
        {
		ui.ImageWidget:new
                {
                        Style = [[
                                fixed: 10 10 285 85;
                        ]],
                        Mode = "button",
                        Image = PPM_mainScreen
                },
		ui.ImageWidget:new
                {
                        Style = [[
                                fixed: 10 86 285 161;
                        ]],
                        Mode = "button",
                        Image = PPM_videoReg
                },
		ui.ImageWidget:new
                {
                        Style = [[
                                fixed: 10 162 285 237;
                        ]],
                        Mode = "button",
                        Image = PPM_autoInfo
                },
		ui.ImageWidget:new
                {
                        Style = [[
                                fixed: 10 238 285 313;
                        ]],
                        Mode = "button",
                        Image = PPM_autoInfo
                },
		ui.ImageWidget:new
                {
                        Style = [[
                                fixed: 10 314 285 389;
                        ]],
                        Mode = "button",
                        Image = PPM_askp
                },
		ui.ImageWidget:new
                {
                        Style = [[
                                fixed: 10 390 285 465;
                        ]],
                        Mode = "button",
                        Image = PPM_infoPanel
                },
		ui.ImageWidget:new
                {
                        Style = [[
                                fixed: 10 466 285 541;
                        ]],
                        Mode = "button",
                        Image = PPM_messages
                },
		ui.ImageWidget:new
                {
                        Style = [[
                                fixed: 10 542 285 617;
                        ]],
                        Mode = "button",
                        Image = PPM_users
                },
		ui.ImageWidget:new
                {
                        Style = [[
                                fixed: 1085 10 1360 85;
                        ]],
                        Mode = "button",
                        Image = PPM_menuSet
                },
		ui.ImageWidget:new
                {
                        Style = [[
                                fixed: 1085 86 1360 161;
                        ]],
                        Mode = "button",
                        Image = PPM_updatePO
                },
		ui.ImageWidget:new
                {
                        Style = [[
                                fixed: 485 10 775 83;
                        ]],
                        Mode = "inert",
                        Image = PPM_header
                },
	}
}

return MenuSet
