local ui = require("tek.ui")

--MENU
local PPM_MMenu = ui.loadImage(ui.ProgDir ..  "/graphics/imageFile/Menu/menu.ppm")
local PPM_Videoregistrator = ui.loadImage(ui.ProgDir ..  "/graphics/imageFile/Menu/videoregistrator.ppm")
local PPM_User = ui.loadImage(ui.ProgDir ..  "/graphics/imageFile/Menu/user.ppm")
local PPM_Autoinfo = ui.loadImage(ui.ProgDir ..  "/graphics/imageFile/Menu/autoinfo.ppm")
local PPM_Sets = ui.loadImage(ui.ProgDir ..  "/graphics/imageFile/Menu/Sets.ppm")
local PPM_Askp = ui.loadImage(ui.ProgDir ..  "/graphics/imageFile/Menu/askpp.ppm")
local PPM_Reload = ui.loadImage(ui.ProgDir ..  "/graphics/imageFile/Menu/interpret.ppm")
local PPM_InfoPanel = ui.loadImage(ui.ProgDir ..  "/graphics/imageFile/Menu/infoPanel.ppm")
local PPM_StateTS = ui.loadImage(ui.ProgDir ..  "/graphics/imageFile/Menu/StateTS.ppm")
local PPM_Message = ui.loadImage(ui.ProgDir ..  "/graphics/imageFile/Menu/message.ppm")
local PPM_SensorFuel = ui.loadImage(ui.ProgDir ..  "/graphics/imageFile/Menu/sensorFuel.ppm")

local MainMenu = ui.Group:new
{
        Layout = "fixed",
        Style = "background-image: url(graphics/imageFile/Background/background2.ppm)",
        Children =
	{
            	ui.ImageWidget:new
                {
                        Style = [[
                                fixed: 600 0 770 70;
                        ]],
                        Mode = "button",
                        Image = PPM_MMenu
                },
		ui.Button:new
		{
			Style = [[
				fixed: 10 70 650 160;
				font: ui-huge/bi:50;
				background-color: gradient(500,0,#f95,400,300,#002);
				color: white;
			]],
			Text = "Видеорегистратор", 
		},
		ui.ImageWidget:new
                {
                       	 Style = "fixed: 750 60 1350 160",
                       	 Mode = "button",
                     	 Image = PPM_User
                },
		ui.ImageWidget:new
                {
                        Style = "fixed: 10 170 650 270",
                        Mode = "button",
                        Image = PPM_Autoinfo
                },
		ui.ImageWidget:new
                {
                        Style = "fixed: 750 180 1350 280",
                        Mode = "button",
                        Image = PPM_Sets
                },
		 ui.ImageWidget:new
                {
                        Style = "fixed: 10 280 650 380",
                        Mode = "button",
                        Image = PPM_Askp
                },
		 ui.ImageWidget:new
                {
                        Style = "fixed: 750 300 1350 400",
                        Mode = "button",
                        Image = PPM_Reload
                },
		ui.ImageWidget:new
                {
                        Style = "fixed: 10 390 650 550",
                        Mode = "button",
                        Image = PPM_InfoPanel
                },
		ui.ImageWidget:new
                {
                        Style = "fixed: 750 420 1350 520",
                        Mode = "button",
                        Image = PPM_StateTS
                },
		ui.ImageWidget:new
                {
                        Style = "fixed: 10 560 650 660",
                        Mode = "button",
                        Image = PPM_Message
                },
		ui.ImageWidget:new
                {
                        Style = "fixed: 670 540 1350 640",
                        Mode = "button",
                        Image = PPM_SensorFuel
                },
        }
}

return MainMenu
