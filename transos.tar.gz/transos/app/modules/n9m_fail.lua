local Config = require 'modules.config'
local utils = require 'modules.utils'
local log = require 'log'

local pickle = require('pickle')
local Camera = require('modules.models.camera')
local Stream = require('modules.models.stream')

local N9M = {}
local c_n9m = require 'c.n9m'


function N9M.parseHeader(header)
  return c_n9m.parseHeader(header)
end

function N9M.makeHeader(payLoadType, payLoad)
  return c_n9m.makeHeader(payLoadType, payLoad)
end

function N9M.parseH264(payLoad)
  return c_n9m.parseH264(payLoad)
end

function N9M.processConnect(dev,data)
  dev.data.online = true
  if dev.data.custom_name == '' then
    dev.data.custom_name = data.CARNUM
  end
  dev.data.auto_number = data.CARNUM
  dev.data.channels_count = data.CHANNEL
  dev.data._raw_connect_data = data
  dev.data.device_type = 'N9M'

  dev.data.last_data = os.time()
end

function N9M.processSPI(dev,data)
  if data.P then
    dev.data.lon = data.P.J
    dev.data.lat = data.P.W
  end

  if data.S and data.S.RE and #data.S.RE==dev.data.channels_count then
    for i=1,dev.data.channels_count do
      local state = data.S.RE[i] or 0
      local camid = dev.id .. '/' .. i
      local cam = Camera:load(camid)
      cam.data.device = dev.id
      cam.data.channel = i
      cam.data.main_channel = state >=2
      cam.data.aux_channel = state % 2 == 1

      local s = Stream:load('/' .. camid  .. '/main')
      if s.data.camera and not cam.data.main_channel then
        s:delete()
      elseif cam.data.main_channel then
        s.data.camera = camid
	print('camid = ' .. camid);
        s.data.channel = i
        s.data.substream = 0
        s:save()
      end

      local s = Stream:load('/' .. camid  .. '/aux')
      if s.data.camera and not cam.data.aux_channel then
        s:delete()
      elseif cam.data.aux_channel then
        s.data.camera = camid
        s.data.channel = i
        s.data.substream = 1
        s:save()
      end

      cam:save()
    end
  end
end

function N9M.stateMonitoring(session, on)
  return {
    MODULE = 'DEVEMM',
    SESSION = session,
    OPERATION = 'SETPOSMONITORING',
    PARAMETER = {
      PGPS = {
        EN = on
      },
      PDSM = {
        REFER = 1
      },
      SERIAL = 0
    }
  }
end

function N9M.requestLiveVideo(name,channel,substream)
  return {
    MODULE='MEDIASTREAMMODEL',OPERATION='REQUESTALIVEVIDEO',PARAMETER={
      AUDIOVALID=1,
      CHANNEL=channel,
      IPANDPORT=string.format('%s:%s',Config.OrbitaX.server_ip,Config.OrbitaX.video_server_port),
      SERIAL=0,
      STREAMNAME=name,
      STREAMTYPE=substream
    },
    SESSION="00000000-0000-0000-0000-000000000000"
  }
end

function N9M.requestArchive(name,channel,substream,isodate)
  return {
    MODULE='MEDIASTREAMMODEL',OPERATION='REQUESTREMOTEPLAYBACK',PARAMETER={
      STARTTIME = os.date('%Y%m%d%H%M%S',utils.date.iso2lua(isodate)),
      AUDIOVALID=1,
      CHANNEL=channel,
      IPANDPORT=string.format('%s:%s',Config.OrbitaX.server_ip,Config.OrbitaX.video_server_port),
      SERIAL=0,
      STREAMNAME=name,
      STREAMTYPE=substream,
      VIDEOTYPE = 0
    },
    SESSION="00000000-0000-0000-0000-000000000000"
  }
end

function N9M.rewindArchive(name,isodate)
  return {
    MODULE='MEDIASTREAMMODEL',OPERATION='CONTROLREMOTEPLAYBACK',PARAMETER={
      STARTTIME = os.date('%Y%m%d%H%M%S',utils.date.iso2lua(isodate)),
      STREAMNAME=name,
      PALYBACKCMD=3
    },
    SESSION="00000000-0000-0000-0000-000000000000"
  }
end

function N9M.stopStream(name)
  return {
    MODULE='MEDIASTREAMMODEL',OPERATION='CONTROLSTREAM',PARAMETER={
      STREAMNAME=name,
      PALYBACKCMD=0
    },
    SESSION="00000000-0000-0000-0000-000000000000"
  }
end

function N9M.requestCalendar()
  return {
    MODULE='STORM',OPERATION='GETCALENDAR',PARAMETER={
      CALENDARTYPE=2,
      CHANNEL=4294967295,
      FILETYPE=65535,
      SERIAL=0,
      STREAMTYPE=1
    },
    SESSION="00000000-0000-0000-0000-000000000000"
  }
end

function N9M.processCalendar(data)
  local r = {}
  if data.CALENDER then
    for _,c in pairs(data.CALENDER) do
      table.insert(r,os.date('%Y-%m-%d',os.time({year=c:sub(1,4),month=c:sub(5,6),day=c:sub(7,8)})))
    end
  end
  return r
end

function N9M.requestFileList(isodate)
  local tm = os.time({year=isodate:sub(1,4),month=isodate:sub(6,7),day=isodate:sub(9,10)})
  return {
    MODULE = 'STORM',OPERATION = 'QUERYFILELIST',PARAMETER = {
      CHANNEL = 4294967295,
      STARTTIME = os.date('%Y%m%d',tm) .. '000000',
      ENDTIME = os.date('%Y%m%d',tm) .. '235959',
      FILETYPE = 65535,
      SERIAL = 0,
      STREAMTYPE = 1
    },
    SESSION="00000000-0000-0000-0000-000000000000"
  }
end

function N9M.processFileList(data)
  local r = {}
  if data.RECORD then
    for i,c in ipairs(data.RECORD) do
      if data.FILETYPE[i] == 1 then
        table.insert(r,{
          starttime = utils.date.lua2iso(os.time({year=c:sub(1,4),month=c:sub(5,6),day=c:sub(7,8),hour=c:sub(9,10),min=c:sub(11,12),sec=c:sub(13,14)})),
          endtime = utils.date.lua2iso(os.time({year=c:sub(16,19),month=c:sub(20,21),day=c:sub(22,23),hour=c:sub(24,25),min=c:sub(26,27),sec=c:sub(28,29)})),
          channel = data.RECORDCHANNEL[i]+1,
          streamtype = data.STREAMTYPE[i],
          recordid = data.RECORDID[i]
        })
      end
    end
  end
  return r
end

function N9M.requestDownload(rec,starttime,endtime,streamname)
  return {
    MODULE='MEDIASTREAMMODEL',OPERATION='REQUESTDOWNLOADVIDEO',PARAMETER={
      STREAMNAME=streamname,
      PT = 3,
      OFFSET = 0,
      OFFSETFLAG = 0,
      SSRC = 1,
      IPANDPORT=string.format('%s:%s',Config.OrbitaX.server_ip,Config.OrbitaX.video_server_port),
      RECORDID = rec,
      STARTTIME = os.date('%Y%m%d%H%M%S',utils.date.iso2lua(starttime)),
      ENDTIME = os.date('%Y%m%d%H%M%S',utils.date.iso2lua(endtime)),
      SERIAL = 0
    },
    SESSION="00000000-0000-0000-0000-000000000000"
  }
end

return N9M

