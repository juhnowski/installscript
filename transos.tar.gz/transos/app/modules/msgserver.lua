Config = require 'modules.config'

log = require 'log'
json=require 'json'
socket = require 'socket'
fiber = require 'fiber'

n9m = require('modules.n9m')
Device = require('modules.models.device')
Camera = require('modules.models.camera')
Stream = require('modules.models.stream')
DevQuery = require('modules.models.devquery')

--[[msgserver садится на порт msg_server_port. Он парсит запросы и формирует ответы.]]
--[[При получении на порт msg_server_port сообщения, будет вызвана функция function(s)]]
socket.tcp_server('0.0.0.0', Config.OrbitaX.msg_server_port, function(s)
  local header, session, dsno, channel, query, connected
  local waiting = 0
  while true do
    -- check device queries
    if connected and os.time()-waiting>10 then
      local queries = DevQuery:by('device',dsno)--Таблица устройств по номеру.
      local requested = {live_video={}};

      for _,q in pairs(queries) do
        if q.data.query == 'live_video' then
          if not requested.live_video[q.data.stream] then
            local st = Stream:load(q.data.stream)
		print('========================msgserver.lua=====================');
            st:find_ports()
--------
	    st:save()
--------
            local request

            if st.data.stream_type == 'archive' then
              request = json.encode(n9m.requestArchive(st.data.name,st.data.channel,st.data.substream,st.data.datetime))
            else
		print('st.data.name = ' .. st.data.name);
		print('st.data.channel = ' .. st.data.channel);
		print('st.data.substream =' .. st.data.substream);
              request = json.encode(n9m.requestLiveVideo(st.data.name,st.data.channel,st.data.substream))
            end
            log.info("sending: " .. request)
	print("(live_video)sending: " .. request);
            s:write(n9m.makeHeader(0,request) .. request)
            requested.live_video[q.data.stream] = true
          end
          q:delete()
          break
        elseif q.data.query == 'download' then
          local streamname = 'download-' .. q.data.starttime:gsub('[^%d]','')
          if q.data.streamname then
            streamname = q.data.streamname
          end
          local streamid = '/' .. q.data.camera .. '/' .. streamname
          local st = Stream:load(streamid)
          st.data.camera = q.data.camera
          st.data.name = streamname
          st.data.stream_type = 'download'
          st.data.file_name = Config.OrbitaX.ARCHIVE_FILES_PATH .. '/'
          if Config.OrbitaX.CAMERA_ID_IS_INT then
            local cam = Camera:load(q.data.camera)
            st.data.file_name = st.data.file_name .. cam.data.number
          else
            st.data.file_name = st.data.file_name .. q.data.camera
          end

          st.data.file_name = st.data.file_name .. '/' .. streamname .. '.h264'

          if q.data.streamdata then
            st.data.streamdata = q.data.streamdata
          end

          st:save()

          local request = json.encode(n9m.requestDownload(q.data.rec,q.data.starttime,q.data.endtime,streamname))
          log.info("sending: " .. request)
	print("(download)sending: " .. request);
          s:write(n9m.makeHeader(0,request) .. request)
          q:delete()
          break
        elseif q.data.query == 'calendar' then
          query = q.id
          local request = json.encode(n9m.requestCalendar())
          log.info("sending: " .. request)
	print("(calendar)sending: " .. request);
          s:write(n9m.makeHeader(0,request) .. request)
          q.data.query = 'calendar:inprocess'
          q:save()
          waiting = os.time()
          break
        elseif q.data.query == 'filelist' then
          query = q.id
          local request = json.encode(n9m.requestFileList(q.data.date))
          log.info("sending: " .. request)
	print("(filelist)sending: " .. request);
          s:write(n9m.makeHeader(0,request) .. request)
          q.data.query = 'filelist:inprocess'
          q:save()
          waiting = os.time()
          break
        elseif q.data.query == 'rewind' then
          local st = Stream:load(q.data.stream)
          local request = json.encode(n9m.rewindArchive(st.data.name,q.data.datetime))
          log.info("sending: " .. request)
	print("(rewind)sending: " .. request);
          s:write(n9m.makeHeader(0,request) .. request)
          q:delete()
          break
        end
      end
    end

    header = s:read(12,1)--Прочитать из сокета 12 байт и подождать 1 секунду.

    if header ~= nil and header ~= '' then
      local payLoadType,payLoadLen = n9m.parseHeader(header)
      local payLoad = s:read(payLoadLen)

      if payLoadType == 0 then -- JSON data
        log.info("JSON received: " .. payLoad)
	print("JSON received: " .. payLoad);

        local data = json.decode(payLoad)
        local dev

        if data.OPERATION == 'CONNECT' then
          session = data.SESSION
          dsno = data.PARAMETER.DSNO
          local response = json.encode{MODULE='CERTIFICATE',OPERATION='CONNECT',RESPONSE={ERRORCAUSE='',ERRORCODE=0},SESSION=session}

          log.info("sending response: " .. response)
	print("sending response: " .. response);
          s:write(n9m.makeHeader(0,response) .. response)

          dev = Device:load(dsno)--Загрузка данных из tarantool.
          n9m.processConnect(dev,data.PARAMETER)--Загрузка в таблицу параметров.
          dev:save()--Сохранение параметров.
---------
---------
          connected = true

          if false then -- doesn't work :(
            -- turn state monitoring on
            local request = json.encode(n9m.stateMonitoring(session,1))
            log.info("sending request: " .. request)
	print("sending request: " .. request);
            s:write(n9m.makeHeader(0,request) .. request)
          end
        elseif data.OPERATION == 'SPI' then
          dev = Device:load(dsno)
          n9m.processSPI(dev,data.PARAMETER)
          dev.data.last_data = os.time()
          dev:save()
        elseif data.OPERATION == 'GETCALENDAR' then
          local q = DevQuery:load(query)
          q.data.calendar = n9m.processCalendar(data.RESPONSE)
          q:save()
          waiting = 0
        elseif data.OPERATION == 'QUERYFILELIST' then
          if data.RESPONSE.RECORD then
            local q = DevQuery:load(query)
            q.data.filelist = n9m.processFileList(data.RESPONSE)
            q:save()
          end
          if data.RESPONSE.LASTRECORD == 1 then
            waiting = 0
          end
        elseif data.OPERATION == 'KEEPALIVE' then
          local response = json.encode{DATA=dsno,MODULE='CERTIFICATE',OPERATION='KEEPALIVE',SESSION=session}
          log.info("sending response: " .. response)
	print("sending response: " .. response);
          s:write(n9m.makeHeader(0,response) .. response)
        end

        if not dev and dsno then
          dev = Device:load(dsno)
          dev.data.last_data = os.time()
          dev:save()
        end
      end
    elseif s:errno() ~= 0 and s:errno() ~= 110 then
      log.error("socket error %d",s:errno())
	print("socket error %d",s:errno());
      break
    else
      fiber.sleep(1)
    end
  end
end)
