Config = require 'modules.config'
Stream = require 'modules.models.stream'
Camera = require 'modules.models.camera'
DevQuery = require 'modules.models.devquery'

log = require 'log'
socket = require 'socket'
io = require 'io'
fiber = require 'fiber'

socket.tcp_server(Config.server_ip, Config.webm_server_port, function(s)
  log.info('(webm) CONNECT')
  local hdrs = s:read{
    chunk = 8192,
    delimiter = { '\n\n', '\r\n\r\n' }
  }

  if hdrs == nil then
    log.error('(webm) failed to read request')
    return
  end

  local cmd = hdrs:match('(.-)\r\n'):sub(1,4):match '^%s*(.-)%s*$'
  local url = hdrs:match('(.-)\r\n'):sub(5):match('(.-)%s')

  local str = Stream:load(url)
  if not str.data.camera then
    s:write('HTTP/1.1 404 Not found\r\n')
    return
  end

  s:write('HTTP/1.1 200 OK\r\n')
  s:write('Date: ' .. os.date('%a, %d %b %Y %T') .. '\r\n')
  s:write('Connection: close\r\n')
  s:write('Cache-Control: private\r\n')
  s:write('Content-Type: video/webm\r\n')
  s:write('Server: CustomStreamer/0.0.1\r\n\r\n')

  local cam = Camera:load(str.data.camera)

  if not str.data.source_online then
    str:find_ports()
    local q = DevQuery:new(nil,{device=cam.data.device,stream=str.id,query='live_video'})
    q:insert()
  end

  if cmd ~= 'GET' or url == '/favicon.ico' then
    return
  end

  local active = true

  socket.tcp_server('0.0.0.0',str.data.webm_port, function(s2)
    while true do
      local buf = s2:read(16384,10)
      if buf ~= nil then
        if not s:write(buf) then
          active = false
        end
      else
        active = false
        break
      end
    end
  end)

  local f = io.popen(string.format('gst-launch-1.0 rtspsrc location=rtsp://%s:%d%s ! rtph264depay ! avdec_h264 ! vp8enc ! webmmux streamable=true ! tcpclientsink host="127.0.0.1" port=%d',Config.server_ip,Config.rtsp_server_port,url,str.data.webm_port), 'r')

  while active and s:writable() do
    fiber.sleep(0.1)
  end

  io.popen('killall -q -r gst-launch-1.0','r')
  f:close()
end)
