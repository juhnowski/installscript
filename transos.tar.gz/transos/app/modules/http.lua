log = require 'log'
Config = require('modules.config')
DevQuery = require('modules.models.devquery')

fiber = require 'fiber'

log.info('Opening http server on '..Config.OrbitaX.server_ip..':'..Config.OrbitaX.http_server_port..'...')
httpd = require('http.server').new(Config.OrbitaX.server_ip, Config.OrbitaX.http_server_port, {app_dir='/root/tarantool_sandbox/http/',cache_templates=false,cache_static=false,cache_controllers=false})

httpd:route{path = '/', file = 'index.html.el'}
httpd:route{path = '/echd.html', file = 'echd.html.el'}
httpd:route{path = '/config.html', file = 'config.html.el'}

httpd:route( {path = '/list/:what'}, 'controller#list')

httpd:route( {path = '/get/:what/:id'}, 'controller#get')
httpd:route( {path = '/get/:what/:id/:subid1'}, 'controller#get')
httpd:route( {path = '/get/:what/:id/:subid1/:subid2'}, 'controller#get')
httpd:route( {path = '/get/:what/:id/:subid1/:subid2/:subid3'}, 'controller#get')

httpd:route( {path = '/put/:what'}, 'controller#put')

httpd:route( {path = '/query/:what/:id'}, 'controller#query')

-- ECHD 
httpd:route( {path = '/getcameras'}, 'echd#getcameras')
httpd:route( {path = '/getdeviceinfo'}, 'echd#getdeviceinfo')
httpd:route( {path = '/getarchiveranges'}, 'echd#getarchiveranges')
httpd:route( {path = '/getliveurl'}, 'echd#getliveurl')
httpd:route( {path = '/createarchivetask'}, 'echd#createarchivetask')
httpd:route( {path = '/getarchivetaskstatus'}, 'echd#getarchivetaskstatus')

httpd:start()
