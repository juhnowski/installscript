local ConfigData = require('modules.models.config'):all()

local Config = {
  OrbitaX = {
    msg_server_port = 5556,
    gst_server_port = 5557,
    rtsp_server_port = 8554,
    webm_server_port = 8555, -- не используется пока!
    http_server_port = 8888,
    video_server_port = 8889,
    gst_min_port = 9000,
    stream_alive_seconds = 5,
    client_alive_seconds = 30,
    stream_wait_seconds = 60,
    --server_ip = '0.0.0.0',
	server_ip = '10.0.0.101',
    GUID_ORBITAX = '111-1-1',
    CAMERA_ID_IS_INT = true,
    ARCHIVE_FILES_PATH = '/root/tarantool_sandbox/video'
  }
}

setmetatable(Config,{__index = function(table,key) return {_empty=true} end})

for i,v in pairs(ConfigData) do
  local modulename,paramname
  if i:find('.',1,true) then
    modulename = i:sub(1,i:find('.',1,true)-1)
    paramname = i:sub(i:find('.',1,true)+1,-1)
  else
    modulename = 'OrbitaX'
    paramname = i
  end

  if Config[modulename]._empty then
    Config[modulename] = {}
  end

  if type(Config[i]) == 'string' then
    Config[modulename][i] = tostring(v.data.value)
  elseif type(Config[i]) == 'number' then
    Config[modulename][i] = tonumber(v.data.value)
  elseif type(Config[i]) == 'boolean' then
    Config[modulename][i] = (type(v.data.value) == 'boolean' and v.data.value) or tonumber(v.data.value)==1 or tostring(v.data.value)=='true'
  end
end

return Config
