Model = require ('modules.models.model')

local Tree = {_space = 'tree',_plain={'parent'},_defaults={parent=0}}
Tree.__index = Tree

setmetatable(Tree, {
  __index = Model
})

return Tree