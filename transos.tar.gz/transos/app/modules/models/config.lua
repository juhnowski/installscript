Model = require ('modules.models.model')

local _Config = {_space = 'config'}
_Config.__index = _Config

setmetatable(_Config, {
  __index = Model
})

function _Config:onsave()
  Config[self.id] = self.data.value
end

return _Config