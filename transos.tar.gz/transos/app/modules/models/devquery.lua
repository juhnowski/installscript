Model = require ('modules.models.model')

local DevQuery = {_space = 'devquery',_plain={'device'}}
DevQuery.__index = DevQuery

setmetatable(DevQuery, {
  __index = Model
})

function DevQuery:onsave()
  if not self.id then
    self.data.created = os.time()
  end
end

return DevQuery