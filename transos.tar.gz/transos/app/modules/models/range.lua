Model = require ('modules.models.model')

local Range = {_space = 'ranges', _plain={'device','camera'}}
Range.__index = Range

setmetatable(Range, {
  __index = Model
})

return Range