﻿local Model = {_space = 'unknown', _plain = {}, _defaults = {}}
Model.__index = Model

function Model:new(id,data)
  for i,v in pairs(self._defaults) do
    if not data[i] then
      data[i] = v
    end
  end
  return setmetatable({id = id, data = data}, self)
end

function Model:load(id)
  local data = box.space[self._space]:get(id) or {id, {}}
	--[[if self._space == 'devices' then
		print('MODEL:LOAD');
		print(data);
	end]]
  return self:new(id,data[2])
end

function Model:complete_tuple(data)
  for _,f in pairs(self._plain) do
    if not self.data[f] then
      error ('No field ' .. f .. ' in data!')
    end
    table.insert(data, self.data[f])
  end
  return data
end

function Model:save()
  self:onsave()
  local data = self:complete_tuple{self.id, self.data}
  box.space[self._space]:replace(data)
end

function Model:insert()
  self:onsave()
  local data = self:complete_tuple{self.data}
  return box.space[self._space]:auto_increment(data)[1]
end

function Model:all()
  local data = box.space[self._space]:select()
  local result = {}
  for _,v in pairs(data) do
    result[v[1]] = self:new(v[1],v[2])
  end
  return result
end

function Model:by(index,value)
  local data = box.space[self._space].index[index]:select(value)
	--[[if self._space == 'cameras' then
		print('MODEL:BY');
		print(value);
		print(#data);
	end]]
  local result = {}
  for i,v in pairs(data) do
	--print(i);
    table.insert(result, self:new(v[1],v[2]))
  end
  return result
end

function Model:delete()
  self:ondelete()
  box.space[self._space]:delete(self.id)
end

function Model:onsave()
end

function Model:ondelete()
end

return Model
