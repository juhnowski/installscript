Model = require ('modules.models.model')

local Camera = {_space = 'cameras', _plain={'device','channel','number'}}
Camera.__index = Camera

setmetatable(Camera, {
  __index = Model
})

function Camera:ondelete()
  local streams = Stream:by('camera',self.id)

  for _,s in pairs(streams) do
    s:delete()
  end
end

function Camera:onsave()
  if not self.data.number then
    self.data.number = (box.space.gen_camera_id:auto_increment{})[1]
  end
end

return Camera