Model = require ('modules.models.model')
Camera = require ('modules.models.camera')
Stream = require ('modules.models.stream')

local Device = {_space = 'devices', _plain={'custom_name','group'}, _defaults={custom_name='',group=0}}
Device.__index = Device

setmetatable(Device, {
  __index = Model
})

function Device:onsave()
  if self.data.device_type == 'IPCAM' then
    self.data.channels_count = 1
  end

  local cameras = Camera:by('device',self.id)
--print('#cameras = ' .. #cameras);

  if #cameras ~= self.data.channels_count then
    --log.error('%d ~= %d',#cameras,self.data.channels_count)
	print('ERROR:Device:onsave() %d ~= %d', #cameras,self.data.channels_count);
    for i = 1,self.data.channels_count do
      local cid = self.id .. '/' .. i

      local cam = Camera:load(cid)
      if not cam.data.device then
        cam.data.device = self.id
        cam.data.channel = i
        cam.data.main_channel = true
        cam.data.aux_channel = false

        local s = Stream:load('/' .. cid .. '/main')
        s.data.camera = cid
        s.data.channel = i
        s.data.substream = 0
        s:save()

        cam:save()
      end
    end
  end
end

function Device:ondelete()
  local cameras = Camera:by('device',self.id)

  for _,c in pairs(cameras) do
    c:delete()
  end
end

return Device
