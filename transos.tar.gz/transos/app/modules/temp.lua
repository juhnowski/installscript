#!/usr/bin/tarantool
box.cfg{};
s = box.space.test;
--[[if not s then
	s = box.schema.space.create('test');
	p = s:create_index('primary', {type = 'tree', parts = {1, 'unsigned'}});
	t = s:insert{1};
	t = s:insert{2, 'Music'};
	t = s:insert{3, 'Length', 93};
	t = s:insert{4, 'Weight', 60}
end]]

--data = box.space['test'].index['primary']:select()
--data = box.space['test'].index['primary']:get(4);
--print(data[3]);
--[[for i,v in pairs(data) do
	print(v[1],v[2]);
end]]

if not s then
	s = box.schema.space.create('test');
	
	p = s:create_index('primary', {--type = 'tree', 
		--unique = false,
		parts = {1,'string'}});
	s:insert{'cur time', 'A'};
	--s:insert{'cur time', 'B'};
	--s:insert{'cur time', 'C'};
end

data = box.space['test'].index['primary']:select{'cur time'};
len_test = box.space['test']:len();
print(data[1][2]);
box.space['test']:update('cur time',{{'=', 2, 'D'}});
print(data[1][2]);
