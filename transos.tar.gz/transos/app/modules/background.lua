fiber = require 'fiber'
Device = require 'modules.models.device'
Stream = require 'modules.models.stream'
DevQuery = require 'modules.models.devquery'
Range = require 'modules.models.range'
Config = require 'modules.config'

fiber.create(function()
  while true do
print("FIBER CREATE");
    local devices = Device:all()
    for _,dev in pairs(devices) do
      if dev.data.online and os.time() - dev.data.last_data > 60 then
        log.info("(background) device is offline")
	print("(background) device is offline");
        dev.data.online = false
        dev:save()
      end

      if dev.data.online and (not dev.data.last_ranges_check or os.time() - dev.data.last_ranges_check > 60*60) then
        log.info("(background) ranges check")
	print("(background) ranges check");

        local q = DevQuery:new(nil,{query = 'calendar',device = dev.id,background=true})
        q:insert()

        dev.data.last_ranges_check = os.time()
        dev:save()
      end
    end

    local streams = Stream:all()
    for _,str in pairs(streams) do
      local save = false
      if str.data.source_online and os.time() - str.data.last_source_data > Config.OrbitaX.stream_alive_seconds then
        log.info("(background) source is offline")
	print("(background) source is offline");
        str.data.source_online = false
        str.data.ports_reserved = false
        if str.data.stream_type ~= 'download' then
          str.data.name = ''
        end
        save = true
      end

      if str.data.source_online and not str.data.client_online and os.time() - (str.data.last_client_query or 0) > Config.OrbitaX.stream_wait_seconds then
	print('11111111111111111111');
        str.data.force_stop = true
        save = true
      end

      if str.data.client_online and os.time() - str.data.last_client_query > Config.OrbitaX.client_alive_seconds then
        log.info("(background) client is offline")
	print("(background) client is offline");
        str.data.client_online = false
        save = true
      end

      if not str.data.source_online and str.data.ports_reserved and os.time() - str.data.ports_reserve_time > 600 then
	print('2222222222222222222222222');
        str.data.ports_reserved = false
        str.data.name = ''
        save = true
      end

      if save then
	print('333333333333333333333333333333');
        str:save()
      end
    end

    local queries = DevQuery:all()
    for _,q in pairs(queries) do
      if q.data.background then
        if q.data.calendar then
          local dates = {}
          for _,d in pairs(q.data.calendar) do
            dates[d] = 0
          end

          local ranges = Range:by('device',q.data.device)
          for _,r in pairs(ranges) do
            local date = r.data.starttime:sub(1,10)
            if not dates[date] then
              r:delete()
            else
              dates[date] = 1
            end
          end

          for d,v in pairs(dates) do
            if v == 0 then
              local q2 = DevQuery:new(nil,{query = 'filelist',device = q.data.device,date=d,background=true})
              q2:insert()
            end
          end

          q:delete()
        elseif q.data.filelist then
          for _,f in pairs(q.data.filelist) do
            local r = Range:new(nil,{
              device = q.data.device,
              camera = q.data.device .. '/' .. f.channel,
              starttime = f.starttime,
              endtime = f.endtime,
              recordid = f.recordid
            })
            r:insert()
          end

          q:delete()
        elseif os.time() - q.data.created > 60 then
          q:delete()
        end

      end
    end

    fiber.sleep(5)
  end
end)
