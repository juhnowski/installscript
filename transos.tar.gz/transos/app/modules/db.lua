box.cfg{
  snapshot_period=3600,
  snapshot_count=3,
  log_level=3
}

if not box.space.config then
  local config = box.schema.space.create('config')
  config:create_index('primary',{unique = true, parts = {1, 'STR'}})
end

Device = require('modules.models.device')
Stream = require('modules.models.stream')
Camera = require('modules.models.camera')
Config = require('modules.config')

if not box.space.devices then
  local devices = box.schema.space.create('devices')
  devices:create_index('primary',{unique = true, parts = {1, 'STR'}})
  devices:create_index('group',{unique = false, parts = {4, 'NUM'}})
end

if not box.space.cameras then
  local cameras = box.schema.space.create('cameras')
  cameras:create_index('primary',{unique = true, parts = {1, 'STR'}})
  cameras:create_index('device',{unique = false, parts = {3, 'STR'}})
  cameras:create_index('number',{unique = true, parts = {5, 'NUM'}})
end

if not box.space.streams then
  local streams = box.schema.space.create('streams')
  streams:create_index('primary',{unique = true, parts = {1, 'STR'}})
  streams:create_index('camera',{unique = false, parts = {3, 'STR'}})
  streams:create_index('name',{unique = false, parts = {4, 'STR'}})
end

if not box.space.tree then
  local tree = box.schema.space.create('tree')
  tree:create_index('primary',{unique = true, parts = {1, 'NUM'}})
  tree:create_index('parent',{unique = false, parts = {3, 'NUM'}})
  tree:insert{0,{name='all',parent=0},0}
end

if box.space.ranges then
  box.space.ranges:drop()
end

if not box.space.ranges then
  local ranges = box.schema.space.create('ranges')
  ranges:create_index('primary',{unique = true, parts = {1, 'NUM'}})
  ranges:create_index('device',{unique = false, parts = {3, 'STR'}})
  ranges:create_index('camera',{unique = false, parts = {4, 'STR'}})
end

if not box.space.gen_camera_id then
  local gen_camera_id = box.schema.space.create('gen_camera_id')
  gen_camera_id:create_index('primary',{unique = true, parts = {1, 'NUM'}})
end

if box.space.devquery then
  box.space.devquery:drop()
end

local q = box.schema.space.create('devquery')
q:create_index('primary',{unique = true, parts = {1, 'NUM'}})
q:create_index('device',{unique = false, parts = {3, 'STR'}})

-- reset
local devices = Device:all()
for i,v in pairs(devices) do
  v.data.online = false
  v.data.last_ranges_check = nil
  v:save()
end

local streams = Stream:all()
for i,v in pairs(streams) do
  v.data.force_stop = nil
  v.data.source_online = false
  v.data.client_online = false
  v.data.ports_reserved = false
  v.data.name = ''
  v:save()
end

