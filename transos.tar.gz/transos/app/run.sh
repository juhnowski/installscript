#!/bin/sh

killall -q -r tarantool

tarantool init.lua > log/error.log 2>&1 &

#killall -q -r rtsp-server
#export LD_LIBRARY_PATH=/usr/local/lib
#./bin/rtsp-server 5557 > log/gerror.log 2>&1 &
