package.path="./?.lua;./lib/luarocks/?.lua"
package.cpath="./bin/?.so"
require 'modules.db'
require 'modules.http'
require 'modules.msgserver'
require 'modules.gstserver'
require 'modules.videoserver'
require 'modules.background'
--require 'modules.webmserver'