$().ready(function(){

  function json(url, data, callback) {
    $.ajax({
      url: url,
      type: 'post',
      dataType: 'json',
      success: callback,
      data: JSON.stringify(data)
    });
  }

  function refresh_tree() {
    $.get('/list/tree',{},function(json){
      function data(id) {
        for(var i in json)
          if(json[i].id==id)
            return json[i];
      }

      function addnode(ul,id) {
        if($('#tree-list').find('a[data-id="'+id+'"]').length) return;

        var d = data(id),
            node = $('<li><a href="#" data-id="'+id+'">'+d.name+'</a></li>'),nodeul = $('<ul></ul>');
        node.appendTo(ul);
        node.data('data',d);
        nodeul.appendTo(node);
        for(var i in json)
          if(json[i].parent==id && json[i].id!=id)
            addnode(nodeul,json[i].id);
      }

      $('#tree-list li').remove();
      addnode($('#tree-list'),0);

      $('#tree-node-parent option').remove();
      for(var i in json) {
        $('#tree-node-parent').append('<option value="'+json[i].id+'">'+json[i].name+'</option>')
        $('#device-group').append('<option value="'+json[i].id+'">'+json[i].name+'</option>')
      }

      $('#tree-list a:eq(0)').click();
    })
  }

  function refresh_devices(group) {
    $.get('/list/device',{},function(json){
      $('#devices-list li').remove();
      for(var i in json)
        if(json[i].group==group)
          $('<li><a href="#" data-id="'+json[i].id+'">'+(json[i].custom_name || '???')+'</a></li>').appendTo($('#devices-list'));

      if(!$('#devices-list a').length)
        $('#device-new').click()
      else
        $('#devices-list a:eq(0)').click();
    });
  }

  function show_node_props(data) {
    $('#tree-node-id').val(data.id)
    $('#tree-node-name').val(data.name)
    $('#tree-node-parent').val(data.parent)
  }

  $('#tree-list').on('click','a',function(){
    $('#tree-list a.active').removeClass('active')
    $(this).addClass('active')
    refresh_devices($(this).attr('data-id'))
    show_node_props($(this).closest('li').data('data'))
    return false;
  });

  $('#tree-node-new').click(function(){
    $('#tree-node-id').val(null)
    $('#tree-node-name').val('new')
    $('#tree-node-parent').val(0)
  })

  $('#tree-node-apply').click(function(){
    json('/put/tree',{
      id: parseInt($('#tree-node-id').val()),
      name: $('#tree-node-name').val(),
      parent: parseInt($('#tree-node-parent').val())
    },refresh_tree)
  })

  $('#tree-node-delete').click(function(){
    json('/put/tree',{
      id: parseInt($('#tree-node-id').val()),
      '@delete':1
    },refresh_tree)
  })

  function show_device_props(id) {
    json('/get/device/'+id,{},function(ajson) {
      var data = ajson.data
      $('#device-id').val(id).toggle(data.device_type=='IPCAM').attr('disabled','disabled')
      $('#device-type').val(data.device_type).attr('disabled','disabled')
      $('#device-name').val(data.custom_name)
      $('#device-group').val(data.group)

      $('#device-info').html('')

      $('#device-info')
        .append($('<dt/>').text('Id'))
        .append($('<dd/>').text(id))
        .append($('<dt/>').text('Status'))
        .append($('<dd/>').text(data.online?'online':'offline'))

      if(data.device_type=='N9M') {
        $('#device-info')
          .append($('<dt/>').text('Auto number'))
          .append($('<dd/>').text(data.auto_number))
      }
      else if(data.device_type=='IPCAM') {
      }

      $('#device-cameras li').remove()

      json('/list/camera',{device:id},function(json){
        for(var i in json.sort(function(x,y){return x.id>y.id}))
          $('<a href="#"></a>').text(json[i].id).wrap($('<li></li>')).parent().appendTo($('#device-cameras'))

        if($('#device-cameras a').length) {
          $('#streams').show()
          $('#device-cameras a:eq(0)').click()
        }
        else
          $('#streams').hide()
      })
    })
  }

  $('#devices-list').on('click','a',function(){
    show_device_props($(this).attr('data-id'))
    return false;
  });

  $('#device-new').click(function(){
    $('#device-id').val(null).show().removeAttr('disabled')
    $('#device-type').val('IPCAM').removeAttr('disabled')
    $('#device-name').val('new')
    $('#device-group').val($('#tree-list a.active').attr('data-id'))
    $('#device-info').html('')
    $('#device-cameras').html('')
    $('#streams').hide()
  })

  $('#device-apply').click(function(){
    var data = {
      id: $('#device-id').val(),
      custom_name: $('#device-name').val(),
      group: parseInt($('#device-group').val())
    }
    if(!$('#device-type').attr('readonly'))
      data.device_type = $('#device-type').val()
    json('/put/device',data,refresh_tree)
  })

  $('#device-delete').click(function(){
    json('/put/device',{
      id: $('#device-id').val(),
      '@delete':1
    },refresh_tree)
  })

  $('#calendar-request').click(function(){
    json('/query/calendar/'+$('#device-id').val(),{},function(json){
      if(json.error) {
        alert(json.error)
        return
      }

      json = json.sort()

      $('#dates').show()
      $('#dates li').remove()
      for(var i in json)
        $('<li><a href="#">'+json[i]+'</a></li>').appendTo($('#dates'));
    })
  })

  $('#dates').on('click','a',function(){
    json('/query/filelist/'+$('#device-id').val(),{date:$(this).text()},function(json){
      if(json.error) {
        alert(json.error)
        return
      }
      $('#dates').hide()
      $('#files li').remove()
      $('#files').show()
      for(var i in json)
        $('<a href="#"></a>')
          .text(json[i].starttime + ' - ' + json[i].endtime)
          .attr('data-channel',json[i].channel)
          .attr('data-streamtype',json[i].streamtype)
          .wrap('<li></li>')
          .parent().appendTo($('#files'));
    })
    return false
  })

  $('#files').on('click','a',function(){
    json('/put/stream',{
      id : '',
      stream_type: 'archive',
      camera: $('#stream-camera-id').text(),
      datetime: $(this).text().split(' - ')[0],
      channel: 1,
      substream: 1
    },function(){
      $('#device-cameras a:contains('+$('#stream-camera-id').text()+')').click()
    })
  })

  $('#device-cameras').on('click','a',function(){
    var _this = this
    $('#stream-camera-id').text($(this).text())
    json('/get/camera/'+$(this).text(),{},function(json){
      $('#stream-camera-number').text(json.data.number)
      $('#camera-main-channel').prop('checked',json.data.main_channel)
      $('#camera-aux-channel').prop('checked',json.data.aux_channel)
    })
    json('/list/stream',{camera:$(this).text()},function(json){
      if(json.error) {
        alert(json.error)
        return
      }
      $('#streams-list li').remove()
      for(var i in json)
        $('<a href="#"></a>').text(json[i].id).wrap('<li></li>').parent().appendTo($('#streams-list'));

      if(!$('#streams-list a').length)
        $('#stream-new').click()
      else
        $('#streams-list a:eq(0)').click();
    })
    return false
  })

  $('#streams-list').on('click','a',function(){
    $.get('/get/stream'+$(this).text(),{},function(json){
      $('#stream-url').html('<a href="rtsp://109.236.81.132:8554/'+json.id+'">rtsp://109.236.81.132:8554'+json.id+'</a>')
      $('#stream-id').val(json.id)
      $('#stream-uri').val(json.data.uri)
      $('#stream-rewind-to').val(json.data.datetime)
      $('#stream-source-status').text(json.data.source_online?'online':'offline')
      $('#stream-client-status').text(json.data.client_online?'online':'offline')
      $('#stream-width').val(json.data.width)
      $('#stream-height').val(json.data.height)
    })
    return false
  })

  $('#stream-new').click(function(){
    $('#stream-id').val(null)
    $('#stream-uri').val('rtsp://')
    $('#stream-url').html('')
  })

  $('#stream-apply').click(function(){
    json('/put/stream',{
      id: $('#stream-id').val(),
      camera: $('#stream-camera-id').text(),
      uri: $('#stream-uri').val()
    })
  })

  $('#stream-delete').click(function(){
    json('/put/stream',{
      id: $('#stream-id').val(),
      '@delete':1
    })
  })

  $('#stream-start').click(function(){
    json('/query/live_video/'+$('#device-id').val(),{
      stream: $('#stream-id').val()
    })
  })

  $('#stream-stop').click(function(){
    json('/put/stream',{
      id: $('#stream-id').val(),
      force_stop: 1
    })
  })

  $('#stream-rewind').click(function(){
    json('/query/rewind/'+$('#device-id').val(),{
      stream: $('#stream-id').val(),
      datetime: $('#stream-rewind-to').val()
    })
  })

  $('.echd-button').click(function(){
    $.get($(this).attr('id'),{
      cameraid:$('#camera-id').val(),
      from:$('#from').val(),
      to:$('#to').val(),
      archiveTaskId:$('#camera-id').val()
    },function(json){
      $('#json-log').val(JSON.stringify(json,null,2))
    })
  })

  $('.save-config').click(function(){
    json('/put/config',{
      id: 'OrbitaX.' + $(this).closest('tr').find('td:eq(0)').text(),
      value: $(this).closest('tr').find('input').val()
    })
    return false
  })

  $('#test-download').click(function(){
    json('/query/download/006100015C',{
      rec:'0-175-0',
      camera:'006100015C/1',
      starttime:'2016-06-01 10:00:00',
      endtime:'2016-06-01 10:05:00'
    })
  })

  refresh_tree()
})