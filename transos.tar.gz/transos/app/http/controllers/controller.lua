return {
list = function (req) 
  local mod = require('modules.models.' .. req:stash('what'))
  local data

  if req.method=='POST' then
    for b,v in pairs(req:json()) do
      data = mod:by(b,v)
      break
    end
  else
    data = mod:all()
  end

  local r = {}
  for i,v in pairs(data) do 
    v.data.id = v.id
    table.insert(r,v.data)
  end

  return req:render({ json =  r }) 
end,

get = function (req)
  local id = req:stash('id')
  local what = req:stash('what')
  if req:stash('subid1') then 
    id = id .. '/' .. req:stash('subid1') 
  end
  if req:stash('subid2') then 
    id = id .. '/' .. req:stash('subid2') 
  end
  if req:stash('subid3') then 
    id = id .. '/' .. req:stash('subid3') 
  end
  if what == 'stream' then
    id = '/' .. id
  end
  local data = require('modules.models.' .. what):load(id)
  return req:render({ json =  data }) 
end,

put = function (req)
  local data = req:json()
  local model = require('modules.models.' .. req:stash('what'))
  local obj
  if data.id~=nil then
    obj = model:load(data.id)
  else
    obj = model:new(nil,{})
  end
  for i,v in pairs(data) do
    if i ~= 'id' then
      obj.data[i] = v
    end
  end
  if data.id~=nil then
    if data['@delete'] then
      obj:delete()
    else
      obj:save()
    end
  else
    obj:insert()
  end
  return req:render({ json =  {status='OK'}}) 
end,

query = function (req)
  local id = req:stash('id')
  local what = req:stash('what')
  local dev = require('modules.models.device'):load(id)
  if not dev.data.online then
    return req:render({ json =  { error='offine' }}) 
  end
  local qdata = {query = what,device = id}
  if req.method=='POST' then
    for p,v in pairs(req:json()) do
      qdata[p] = v
    end
  end
  local obj = DevQuery:new(nil,qdata)
  local q = obj:insert()

  if(what == 'live_video' or what == 'rewind' or what == 'download') then
    return req:render({ json =  { status='OK' }}) 
  end

  local count = 0
  while count < 10 do
    fiber.sleep(1)
    obj = DevQuery:load(q)
    if obj.data[what] then
      obj:delete()
      return req:render({ json = obj.data[what] })
    end
    count = count + 1
  end
  return req:render({ json =  { error='timeout' }}) 
end

}
