function loadanycam(camid)
  local cam
  if camid:find('/') then
    cam = require('modules.models.camera'):load(camid)
  else
    cam = require('modules.models.camera'):by('number',tonumber(camid))
    if #cam == 1 then
      cam = cam[1]
    else
      cam = {id='??'}
    end
  end

  return cam
end

return {

getcameras = function(req)
  local data = require('modules.models.camera'):all()

  local r = {}
  for _,v in pairs(data) do 
    if v.data.main_channel then
      local dev = require('modules.models.device'):load(v.data.device)
      table.insert(r,{id = Config.CAMERA_ID_IS_INT and v.data.number or v.id, channel = v.id, status = dev.data.online and 'working' or 'signal lost'})
    end
  end

  return req:render({ json =  {cameras = r} }) 
end,

getdeviceinfo = function(req)
  return req:render({ json = 
  {
    firmware_version = '1.0',
    vendor = 'Transorbita',
    model =  'Mobile DVR Adapter',
    serial_number = Config.GUID_ORBITAX,
    ['ptz-status'] = 'not supported'
  }})
end,

getarchiveranges = function(req)
  local cam = loadanycam(req:param('cameraid'))

  local ranges = require('modules.models.range'):by('camera',cam.id)
  local r = {}
  local utils = require 'modules.utils'
  for _,v in pairs(ranges) do
    table.insert(r,{from=utils.date.iso2lua(v.data.starttime),to=utils.date.iso2lua(v.data.endtime)})
  end

  return req:render({ json = 
  {
    cameraid = req:param('cameraid'),
    ranges = r
  }})
end,

getliveurl = function(req)
  local cam = loadanycam(req:param('cameraid'))

  local url = nil
  local streams = require('modules.models.stream'):by('camera',cam.id)
  for _,v in pairs(streams) do
    if v.data.substream == 0 then
      url = v.id
    end
  end

  return req:render({ json = 
  {
    rtspurl = url and ('rtsp://' .. Config.server_ip .. ':' .. Config.rtsp_server_port .. url) or 'error: not found'
  }})
end,

createarchivetask = function(req)
  local cam = loadanycam(req:param('cameraid'))

  local r = {
    cameraid = req:param('cameraid'),
    from = req:param('from'),
    to = req:param('to')
  }

  if cam.id ~= '??' then
    local from = req:param('from')
    local to = req:param('to')
    local utils = require 'modules.utils'
    local uuid = require 'uuid'

    local ranges = (require 'modules.models.range'):by('camera',cam.id)
    table.sort(ranges,function(x,y)
      return x.data.starttime < y.data.starttime
    end)

    local _from = utils.date.iso2lua(from)
    local _to = utils.date.iso2lua(to)

    for _,v in pairs(ranges) do
      local st = utils.date.iso2lua(v.data.starttime)
      local et = utils.date.iso2lua(v.data.endtime)
      if st <= _from and et > _from then
        local taskid = uuid.str()
        local DevQuery = require 'modules.models.devquery'
        local q = DevQuery:new(nil,{
          query = 'download',
          device = cam.data.device,
          camera = cam.id,
          rec = v.data.recordid,
          starttime = utils.date.lua2iso(_from),
          endtime = utils.date.lua2iso(et < _to and et or _to),
          streamname = taskid,
          streamdata = {
            cameraid = req:param('cameraid'),
            from = req:param('from'),
            to = req:param('to')
          }
        })

        q:insert()

        r.state = 'Created'
        r.archiveTaskId = taskid

        break
      end
    end

    if not r.archiveTaskId then
      r.state = 'Error'
      r.errorMessage = 'range not found'
    end
  else
    r.state = 'Error'
    r.errorMessage = 'camera not found'
  end

  return req:render({ json = r })
end,

getarchivetaskstatus = function(req)
  local taskid = req:param('archiveTaskId')
  local stream = (require 'modules.models.stream'):by('name',taskid)
  local r

  if #stream == 1 then
    stream = stream[1]
    r = stream.data.streamdata
    r.archiveTaskId = taskid

    if stream.data.completed then
      r.state='ReadyForDownload'
      r.url = 'http://'.. Config.server_ip .. stream.data.file_name
    elseif stream.data.source_online then
      r.state='Working'
    else
      r.state='Error'
      r.errorMessage='download error'
    end
  else
    r = {state = 'Error', errorMessage = 'task not found'}
  end

  return req:render({ json = r })
end

}
